( function () {
	const cfg = window.BS || {};
	const freeAt = Number( cfg.freeAt ) || 5000;
	const POTS = cfg.pots || {};
	const EXTRAS = cfg.extras || {};
	const fmt = ( n ) => 'KSh ' + Math.round( n ).toLocaleString( 'en-KE' );
	const $$ = ( sel, root = document ) => Array.from( root.querySelectorAll( sel ) );
	const esc = ( s ) => String( s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	// Store API names come HTML-encoded (e.g. &#8211;); turn them back into plain text.
	const plain = ( s ) => new DOMParser().parseFromString( String( s ), 'text/html' ).documentElement.textContent;
	const money = ( minor, prices ) => Number( minor ) / Math.pow( 10, ( prices && prices.currency_minor_unit ) || 0 );
	const heart = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg>';
	const waLink = ( text ) => 'https://wa.me/' + ( cfg.wa || '' ) + '?text=' + encodeURIComponent( text );

	/* Plant data (printed in the footer) ---------------------------------- */
	let DATA = null;
	const byId = {};
	function data() {
		if ( DATA ) return DATA;
		const el = document.getElementById( 'bs-data' );
		try {
			DATA = el ? JSON.parse( el.textContent ) : [];
		} catch ( e ) {
			DATA = [];
		}
		DATA.forEach( ( p ) => {
			byId[ p.id ] = p;
			p.vars.forEach( ( v ) => ( byId[ v.id ] = p ) );
		} );
		return DATA;
	}
	const optionsCost = ( o ) => ( o.pot ? ( POTS[ o.pot ] || [ 0, 0 ] )[ 1 ] : 0 ) + ( o.extras || [] ).reduce( ( t, e ) => t + ( EXTRAS[ e ] ? EXTRAS[ e ][ 1 ] : 0 ), 0 );

	/* Toasts ------------------------------------------------------------ */
	function toast( msg ) {
		let box = document.querySelector( '.bs-toasts' );
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'bs-toasts';
			box.setAttribute( 'role', 'status' );
			box.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( box );
		}
		const t = document.createElement( 'div' );
		t.className = 'bs-toast';
		t.innerHTML = msg;
		box.appendChild( t );
		setTimeout( () => t.classList.add( 'is-out' ), 3200 );
		setTimeout( () => t.remove(), 3700 );
	}
	window.bsToast = toast;
	document.body.addEventListener( 'wc-blocks_added_to_cart', ( e ) => {
		// The static copy shows its own toast with a link to the cart.
		if ( ! window.BS_STATIC && ! ( e.detail && e.detail.bsQuiet ) ) toast( '🌿 Added to your cart' );
	} );
	if ( window.jQuery ) window.jQuery( document.body ).on( 'added_to_cart', () => toast( '🌿 Added to your cart' ) );

	/* Store API ---------------------------------------------------------- */
	let nonce = '';
	async function getCart() {
		const res = await fetch( cfg.store + 'cart', { credentials: 'same-origin' } );
		nonce = res.headers.get( 'Nonce' ) || nonce;
		return res.json();
	}
	// The header mini cart keeps its own copy of the cart (Interactivity API, or wp.data on
	// older WooCommerce); tell whichever is on the page to reload it.
	async function refreshMiniCart( cart ) {
		try {
			const { store } = await import( '@wordpress/interactivity' );
			const wc = store( 'woocommerce' );
			if ( wc && wc.actions && wc.actions.refreshCartItems ) await wc.actions.refreshCartItems();
		} catch ( e ) {}
		const wpData = window.wp && window.wp.data;
		if ( cart && wpData && wpData.dispatch( 'wc/store/cart' ) && wpData.dispatch( 'wc/store/cart' ).receiveCart ) {
			wpData.dispatch( 'wc/store/cart' ).receiveCart( cart );
		}
	}
	async function syncBar() {
		try {
			const cart = await getCart();
			renderBar( money( cart.totals.total_items, cart.totals ) );
		} catch ( e ) {}
	}
	document.body.addEventListener( 'wc-blocks_removed_from_cart', syncBar );
	document.body.addEventListener( 'wc-blocks_added_to_cart', () => setTimeout( syncBar, 400 ) );
	// Quantity buttons and remove links inside the mini cart drawer.
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.closest( '.wc-block-mini-cart__drawer button, .wc-block-mini-cart__drawer a' ) && ! e.target.closest( '[data-bs-wa-cart]' ) ) setTimeout( syncBar, 900 );
	} );

	// Adds one plant (with its pot and add-ons) or several plants, then updates the mini cart once.
	async function addToCart( ids, btn, opts, qty ) {
		ids = [].concat( ids ).map( Number ).filter( Boolean );
		if ( btn ) btn.disabled = true;
		try {
			if ( ! nonce ) await getCart();
			let cart;
			if ( ids.length === 1 ) {
				const res = await fetch( cfg.store + 'cart/add-item', {
					method: 'POST',
					credentials: 'same-origin',
					headers: { 'Content-Type': 'application/json', Nonce: nonce },
					body: JSON.stringify( { id: ids[ 0 ], quantity: qty || 1, bs: opts || {} } ),
				} );
				cart = await res.json();
				if ( ! res.ok ) throw new Error( cart.message || 'Could not add' );
			} else {
				if ( btn ) btn.dataset.label = btn.textContent;
				if ( btn ) btn.textContent = 'Adding ' + ids.length + ' plants…';
				const res = await fetch( cfg.store + 'batch', {
					method: 'POST',
					credentials: 'same-origin',
					headers: { 'Content-Type': 'application/json', Nonce: nonce },
					body: JSON.stringify( { requests: ids.map( ( id ) => ( { path: '/wc/store/v1/cart/add-item', method: 'POST', body: { id, quantity: 1 }, headers: { Nonce: nonce } } ) ) } ),
				} );
				const out = await res.json();
				const failed = ( out.responses || [] ).find( ( r ) => r.status >= 400 );
				if ( ! res.ok || failed ) throw new Error( ( failed && failed.body && failed.body.message ) || out.message || 'Could not add' );
				cart = await getCart();
				toast( '🌿 ' + ids.length + ' plants added to your cart' );
			}
			await refreshMiniCart( cart );
			// The mini cart opens its drawer on this event.
			document.body.dispatchEvent( new CustomEvent( 'wc-blocks_added_to_cart', { bubbles: true, detail: { bsQuiet: ids.length > 1 } } ) );
			setTimeout( () => refreshMiniCart(), 900 );
			renderBar( money( cart.totals.total_items, cart.totals ) );
			return true;
		} catch ( e ) {
			toast( esc( plain( e.message || 'Could not add to cart. Please try again.' ) ) );
			return false;
		} finally {
			if ( btn ) btn.disabled = false;
			if ( btn && btn.dataset.label ) btn.textContent = btn.dataset.label;
		}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-bs-add], [data-bs-add-many]' );
		if ( ! b ) return;
		e.preventDefault();
		addToCart( ( b.dataset.bsAdd || b.dataset.bsAddMany ).split( ',' ), b );
	} );

	/* WhatsApp order from the cart ---------------------------------------- */
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-bs-wa-cart]' );
		if ( ! b ) return;
		e.preventDefault();
		// Open the tab now (inside the click) so pop-up blockers allow it, then fill in the link.
		const win = window.open( '', '_blank' );
		try {
			const cart = await getCart();
			if ( ! cart.items || ! cart.items.length ) {
				if ( win ) win.close();
				toast( 'Your cart is empty.' );
				return;
			}
			const lines = [ 'Hi Bloem Sefa, I\'d like to order:' ];
			cart.items.forEach( ( it ) => {
				const picks = ( it.variation || [] ).map( ( v ) => v.value ).concat( ( it.item_data || [] ).map( ( d ) => plain( d.key || d.name ) + ': ' + plain( d.value ) ) );
				lines.push( '• ' + it.quantity + ' × ' + plain( it.name ) + ( picks.length ? ' (' + picks.join( '; ' ) + ')' : '' ) + ' – ' + fmt( money( it.totals.line_total, it.totals ) ) );
			} );
			( cart.coupons || [] ).forEach( ( c ) => lines.push( 'Promo code: ' + c.code.toUpperCase() ) );
			lines.push( 'Subtotal: ' + fmt( money( cart.totals.total_items, cart.totals ) - money( cart.totals.total_discount, cart.totals ) ) + ' (plus delivery)' );
			lines.push( 'Deliver to: ' );
			const url = waLink( lines.join( '\n' ) );
			if ( win ) win.location = url;
			else window.location = url;
		} catch ( err ) {
			if ( win ) win.close();
			toast( 'Could not read your cart. Please try again.' );
		}
	} );

	/* Wishlist ---------------------------------------------------------- */
	const KEY = 'bs-wishlist';
	const readWish = () => {
		try {
			return JSON.parse( localStorage.getItem( KEY ) || '[]' ).map( Number ).filter( Boolean );
		} catch ( e ) {
			return [];
		}
	};
	const writeWish = ( ids ) => {
		try {
			localStorage.setItem( KEY, JSON.stringify( ids ) );
		} catch ( e ) {}
	};
	function paintWish() {
		const ids = readWish();
		// Only touch the DOM when something changed: the MutationObserver below calls this.
		$$( '[data-bs-wish]' ).forEach( ( b ) => {
			const on = ids.includes( Number( b.dataset.bsWish ) );
			if ( b.classList.contains( 'is-on' ) === on ) return;
			b.classList.toggle( 'is-on', on );
			b.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
		} );
		$$( '[data-bs-wish-count]' ).forEach( ( el ) => {
			if ( el.textContent !== String( ids.length ) ) el.textContent = ids.length;
			el.hidden = ids.length === 0;
		} );
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-bs-wish]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const id = Number( b.dataset.bsWish );
		let ids = readWish();
		const on = ids.includes( id );
		ids = on ? ids.filter( ( x ) => x !== id ) : [ ...ids, id ];
		writeWish( ids );
		paintWish();
		toast( on ? 'Removed from your wishlist' : '♥ Saved to your <a href="' + esc( cfg.home || '/' ) + 'wishlist/">wishlist</a>' );
		if ( b.closest( '[data-bs-wishlist]' ) ) renderWishlist();
	} );

	const fromPrice = ( p ) => ( p.vars.length && p.vars.some( ( v ) => v.price !== p.price ) ? '<span class="bs-from">From</span> ' : '' ) + fmt( p.price );
	// One tap adds simple plants; plants with colours or pots open the quick view to choose.
	const buyButton = ( p, label ) => {
		if ( ! p.inStock ) return '<span class="bs-tag bs-tag--out">Sold out</span>';
		return p.vars.length || p.pots
			? '<button type="button" class="wp-element-button" data-bs-qv="' + p.id + '">' + ( label || ( p.vars.length ? 'Choose ' + esc( p.attr.toLowerCase() ) : 'Choose pot' ) ) + '</button>'
			: '<button type="button" class="wp-element-button" data-bs-add="' + p.id + '">Add to cart</button>';
	};

	function renderWishlist() {
		const box = document.querySelector( '[data-bs-wishlist]' );
		if ( ! box ) return;
		const ids = readWish();
		const items = data().filter( ( p ) => ids.includes( p.id ) );
		if ( ! items.length ) {
			box.innerHTML = '<div class="bs-empty"><p>Your wishlist is empty. Tap the ♥ on any plant to save it here.</p><a class="wp-element-button" href="' + esc( cfg.shop || '/shop/' ) + '">Browse the plants</a></div>';
			return;
		}
		box.innerHTML = '<div class="bs-wish-grid">' + items.map( ( p ) =>
			'<article class="bs-wish-card"><a href="' + esc( p.url ) + '">' + ( p.imgs[ 0 ] ? '<img src="' + esc( p.imgs[ 0 ].thumb ) + '" alt="" loading="lazy">' : '' ) + '</a>' +
			'<button type="button" class="bs-heart is-on" data-bs-wish="' + p.id + '" aria-label="Remove from wishlist" aria-pressed="true">' + heart + '</button>' +
			'<h3><a href="' + esc( p.url ) + '">' + esc( p.name ) + '</a></h3><div class="bs-wish-price">' + fromPrice( p ) + '</div>' + buyButton( p ) + '</article>'
		).join( '' ) + '</div>';
	}

	/* Quick view: photos, colour, pot, add-ons and care sheet -------------- */
	function optionsHtml( p ) {
		let h = '';
		if ( p.pots ) {
			h += '<fieldset class="bs-pots"><legend>Pot <span data-bs-pot-name>' + esc( POTS.grower[ 0 ] ) + '</span></legend><div class="bs-pots__row">' +
				Object.entries( POTS ).map( ( [ k, [ label, price, hex ] ] ) =>
					'<label class="bs-pot" title="' + esc( label ) + '"><input type="radio" name="qv-pot" value="' + k + '"' + ( k === 'grower' ? ' checked' : '' ) + '><span class="bs-pot__swatch" style="--pot:' + hex + '"></span><span class="bs-pot__txt">' + esc( label ) + '<em>' + ( price ? '+' + fmt( price ) : 'Included' ) + '</em></span></label>'
				).join( '' ) + '</div></fieldset>';
		}
		h += '<fieldset class="bs-extras"><legend>Add-ons</legend>' + Object.entries( EXTRAS ).filter( ( [ k ] ) => p.pots || k === 'gift' ).map( ( [ k, [ label, price, hint ] ] ) =>
			'<label class="bs-extra"><input type="checkbox" name="qv-extra" value="' + k + '"><span><strong>' + esc( label ) + '</strong><em>' + esc( hint ) + '</em></span><b>+' + fmt( price ) + '</b></label>'
		).join( '' ) + '<label class="bs-card" hidden data-bs-card><span>Your card message</span><textarea name="qv-card" rows="2" maxlength="200" placeholder="e.g. Happy birthday Wanjiru! Love, Ken"></textarea></label></fieldset>';
		return h;
	}
	function openQuickView( id ) {
		data();
		const p = byId[ id ];
		const dlg = document.getElementById( 'bs-qv' );
		const body = dlg && dlg.querySelector( '[data-bs-qv-body]' );
		if ( ! p || ! body || ! dlg.showModal ) {
			if ( p ) location.href = p.url;
			return;
		}
		const first = p.vars.find( ( v ) => v.inStock ) || p.vars[ 0 ];
		const imgs = p.imgs.map( ( im ) => im.src );
		body.innerHTML = '<div class="bs-qv__grid"><div class="bs-qv__media"><div class="bs-qv__main"><img data-bs-qv-main src="' + esc( ( first && first.img ) || imgs[ 0 ] || '' ) + '" alt="' + esc( p.name ) + '"><span class="bs-pot-chip" data-bs-pot-chip hidden></span></div>' +
			( imgs.length > 1 ? '<div class="bs-qv__thumbs">' + p.imgs.slice( 0, 6 ).map( ( im ) => '<button type="button" data-bs-qv-img="' + esc( im.src ) + '"><img src="' + esc( im.thumb ) + '" alt=""></button>' ).join( '' ) + '</div>' : '' ) + '</div>' +
			'<form class="bs-qv__info" data-bs-qv-form><p class="bs-eyebrow">' + esc( p.catName ) + '</p><h2>' + esc( p.name ) + '</h2>' +
			'<div class="bs-qv__price" data-bs-qv-price></div><p class="bs-qv__desc">' + esc( p.short ) + '</p>' +
			( p.vars.length ? '<fieldset class="bs-colours"><legend>' + esc( p.attr ) + ' <span data-bs-var-name></span></legend><div class="bs-colours__row">' + p.vars.map( ( v ) =>
				'<label class="bs-colour' + ( v.hex ? '' : ' bs-colour--text' ) + '" title="' + esc( v.label ) + '"><input type="radio" name="qv-var" value="' + v.id + '"' + ( v === first ? ' checked' : '' ) + ( v.inStock ? '' : ' disabled' ) + '>' + ( v.hex ? '<span style="--c:' + v.hex + '"></span>' : '<span>' + esc( v.label ) + '</span>' ) + '</label>'
			).join( '' ) + '</div></fieldset>' : '' ) +
			optionsHtml( p ) +
			'<div class="bs-qv__buy"><div class="bs-qty"><button type="button" data-q="-1" aria-label="One less">−</button><input name="qv-qty" type="number" min="1" value="1" aria-label="Quantity"><button type="button" data-q="1" aria-label="One more">+</button></div>' +
			( p.inStock ? '<button type="submit" class="wp-element-button" data-bs-qv-add>Add to cart</button>' : '<span class="bs-tag bs-tag--out">Sold out</span>' ) + '</div>' +
			( p.care.length ? '<div class="bs-care bs-care--qv"><p class="bs-care__title">Care sheet</p>' + p.care.map( ( [ label, text ], i ) => '<details class="bs-care__row"' + ( i ? '' : ' open' ) + '><summary>' + esc( label ) + '</summary><p>' + esc( text ) + '</p></details>' ).join( '' ) + '</div>' : '' ) +
			'<a class="bs-link" href="' + esc( p.url ) + '">Full details, photos &amp; delivery →</a></form></div>';
		const form = body.querySelector( '[data-bs-qv-form]' );
		const paint = () => {
			const vid = Number( ( form.querySelector( '[name="qv-var"]:checked' ) || {} ).value || 0 );
			const v = p.vars.find( ( x ) => x.id === vid );
			const o = readOpts( form, 'qv-' );
			const qty = Math.max( 1, Number( form.querySelector( '[name="qv-qty"]' ).value ) || 1 );
			const base = v ? v.price : p.price;
			const reg = v ? v.regular : p.regular;
			const each = base + optionsCost( o );
			form.querySelector( '[data-bs-qv-price]' ).innerHTML = ( reg > base ? '<del>' + fmt( reg ) + '</del> ' : '' ) + '<strong>' + fmt( each * qty ) + '</strong>' + ( optionsCost( o ) || qty > 1 ? '<small>' + fmt( base ) + ' plant' + ( optionsCost( o ) ? ' + ' + fmt( optionsCost( o ) ) + ' extras' : '' ) + ( qty > 1 ? ' × ' + qty : '' ) + '</small>' : '' );
			const name = form.querySelector( '[data-bs-var-name]' );
			if ( name && v ) name.textContent = v.label;
			if ( v && v.img ) body.querySelector( '[data-bs-qv-main]' ).src = v.img;
			paintPot( form, body, o );
		};
		form.addEventListener( 'change', paint );
		form.addEventListener( 'input', paint );
		form.addEventListener( 'click', ( e ) => {
			const q = e.target.closest( '[data-q]' );
			if ( ! q ) return;
			const input = form.querySelector( '[name="qv-qty"]' );
			input.value = Math.max( 1, ( Number( input.value ) || 1 ) + Number( q.dataset.q ) );
			paint();
		} );
		form.addEventListener( 'submit', async ( e ) => {
			e.preventDefault();
			const vid = Number( ( form.querySelector( '[name="qv-var"]:checked' ) || {} ).value || 0 );
			const ok = await addToCart( vid || p.id, form.querySelector( '[data-bs-qv-add]' ), readOpts( form, 'qv-' ), Math.max( 1, Number( form.querySelector( '[name="qv-qty"]' ).value ) || 1 ) );
			if ( ok ) dlg.close();
		} );
		paint();
		dlg.showModal();
	}
	// Pot, add-ons and card message from a form; field names start with `prefix` ("qv-") or are bs[...].
	function readOpts( form, prefix ) {
		const pick = ( n ) => prefix ? form.querySelectorAll( '[name="' + prefix + n + '"]' ) : form.querySelectorAll( '[name="bs[' + n + ']"], [name="bs[' + n + '][]"]' );
		const pot = Array.from( pick( 'pot' ) ).find( ( i ) => i.checked );
		const extras = Array.from( pick( prefix ? 'extra' : 'extras' ) ).filter( ( i ) => i.checked ).map( ( i ) => i.value );
		const card = pick( 'card' )[ 0 ];
		const o = {};
		if ( pot && pot.value !== 'grower' ) o.pot = pot.value;
		if ( extras.length ) o.extras = extras;
		if ( card && extras.includes( 'gift' ) && card.value.trim() ) o.card = card.value.trim();
		return o;
	}
	// The chosen pot's name, its chip on the photo, and the card message box when gift wrap is ticked.
	function paintPot( form, media, o ) {
		const label = POTS[ o.pot || 'grower' ];
		const name = form.querySelector( '[data-bs-pot-name]' );
		if ( name && label ) name.textContent = label[ 0 ];
		const chip = media && media.querySelector( '[data-bs-pot-chip]' );
		if ( chip ) {
			chip.hidden = ! o.pot;
			if ( o.pot ) chip.innerHTML = '<i style="--pot:' + POTS[ o.pot ][ 2 ] + '"></i>Comes in a ' + esc( POTS[ o.pot ][ 0 ].toLowerCase() ) + ( o.pot === 'basket' ? '' : ' pot' );
		}
		const card = form.querySelector( '[data-bs-card]' );
		if ( card ) card.hidden = ! ( o.extras || [] ).includes( 'gift' );
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-bs-qv]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		openQuickView( Number( b.dataset.bsQv ) );
	} );
	// "Choose colour" on a product card opens the quick view instead of leaving the page.
	document.addEventListener( 'click', ( e ) => {
		const a = e.target.closest( '.wc-block-product a.wp-block-button__link, .wc-block-product a.wc-block-components-product-button__button' );
		const heart = a && a.closest( '.wc-block-product' ).querySelector( '[data-bs-wish]' );
		if ( ! heart || e.ctrlKey || e.metaKey ) return;
		data();
		if ( ! byId[ heart.dataset.bsWish ] ) return;
		e.preventDefault();
		openQuickView( Number( heart.dataset.bsWish ) );
	} );
	document.addEventListener( 'click', ( e ) => {
		const t = e.target.closest( '[data-bs-qv-img]' );
		if ( ! t ) return;
		t.closest( '.bs-qv__media' ).querySelector( '[data-bs-qv-main]' ).src = t.dataset.bsQvImg;
	} );
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.matches( 'dialog.bs-dialog' ) ) e.target.close();
	} );

	/* Product page: live total with the pot and add-ons ------------------- */
	function initProductOptions() {
		const box = document.querySelector( 'form.cart [data-bs-options]' );
		if ( ! box ) return;
		const form = box.closest( 'form' );
		const p = data().find( ( x ) => x.id === Number( ( form.querySelector( '[name="add-to-cart"]' ) || form.querySelector( '[name="product_id"]' ) || {} ).value ) );
		const gallery = document.querySelector( '.woocommerce-product-gallery' );
		let chip = null;
		if ( gallery ) {
			chip = document.createElement( 'span' );
			chip.className = 'bs-pot-chip';
			chip.hidden = true;
			chip.setAttribute( 'data-bs-pot-chip', '' );
			gallery.appendChild( chip );
		}
		const total = box.querySelector( '[data-bs-total]' );
		const paint = () => {
			const o = readOpts( form, '' );
			paintPot( form, gallery, o );
			if ( ! p ) return;
			const vid = Number( ( form.querySelector( '[name="variation_id"]' ) || {} ).value || 0 );
			const v = p.vars.find( ( x ) => x.id === vid );
			if ( p.vars.length && ! v ) {
				total.hidden = true;
				return;
			}
			const qty = Math.max( 1, Number( ( form.querySelector( 'input.qty' ) || {} ).value ) || 1 );
			const extra = optionsCost( o );
			const base = v ? v.price : p.price;
			total.hidden = ! extra && qty === 1;
			total.querySelector( 'strong' ).textContent = fmt( ( base + extra ) * qty ) + ( extra ? ' (' + fmt( base ) + ' plant + ' + fmt( extra ) + ' extras' + ( qty > 1 ? ', × ' + qty : '' ) + ')' : qty > 1 ? ' (× ' + qty + ')' : '' );
		};
		form.addEventListener( 'change', paint );
		form.addEventListener( 'input', paint );
		if ( window.jQuery ) window.jQuery( form ).on( 'found_variation reset_data', () => setTimeout( paint, 0 ) );
		paint();
	}

	/* Instant search ----------------------------------------------------- */
	function initSearch() {
		$$( '.bs-search input[type="search"]' ).forEach( ( input ) => {
			const form = input.closest( 'form' );
			const list = document.createElement( 'div' );
			list.className = 'bs-suggest';
			list.hidden = true;
			form.style.position = 'relative';
			form.appendChild( list );
			let timer;
			input.setAttribute( 'autocomplete', 'off' );
			input.addEventListener( 'input', () => {
				clearTimeout( timer );
				const q = input.value.trim().toLowerCase();
				if ( q.length < 2 ) {
					list.hidden = true;
					return;
				}
				timer = setTimeout( () => {
					const words = q.split( /\s+/ );
					const items = data().filter( ( p ) => words.every( ( w ) => ( p.name + ' ' + p.catName + ' ' + p.short + ' ' + p.vars.map( ( v ) => v.label ).join( ' ' ) ).toLowerCase().includes( w ) ) ).slice( 0, 6 );
					list.innerHTML = items.length
						? items.map( ( p ) => '<a href="' + esc( p.url ) + '">' + ( p.imgs[ 0 ] ? '<img src="' + esc( p.imgs[ 0 ].thumb ) + '" alt="">' : '' ) + '<span>' + esc( p.name ) + '<small>' + fromPrice( p ) + '</small></span></a>' ).join( '' ) + '<button type="submit">See all results for “' + esc( input.value.trim() ) + '”</button>'
						: '<p>No plants match “' + esc( input.value.trim() ) + '”. <a href="' + esc( waLink( 'Hi Bloem Sefa, do you have ' + input.value.trim() + '?' ) ) + '" target="_blank" rel="noopener">Ask us on WhatsApp</a></p>';
					list.hidden = false;
				}, 120 );
			} );
			document.addEventListener( 'click', ( e ) => {
				if ( ! form.contains( e.target ) ) list.hidden = true;
			} );
			input.addEventListener( 'keydown', ( e ) => {
				if ( e.key === 'Escape' ) list.hidden = true;
			} );
		} );
	}

	/* Colour options on the product page as buttons ----------------------- */
	function initSwatches() {
		const jq = window.jQuery;
		if ( ! jq ) return;
		$$( 'form.variations_form table.variations select' ).forEach( ( sel ) => {
			const all = Array.from( sel.options ).filter( ( o ) => o.value ).map( ( o ) => ( { v: o.value, t: o.textContent } ) );
			const p = data().find( ( x ) => x.id === Number( sel.form.dataset.product_id ) );
			const hex = ( t ) => ( p && ( p.vars.find( ( v ) => v.label === t ) || {} ).hex ) || '';
			const wrap = document.createElement( 'div' );
			wrap.className = 'bs-swatches';
			// WooCommerce removes the choices that don't exist with what is already picked.
			const paint = () => {
				const live = new Set( Array.from( sel.options ).filter( ( o ) => o.value && ! o.disabled ).map( ( o ) => o.value ) );
				wrap.innerHTML = all.map( ( o ) => '<button type="button" class="bs-swatch' + ( sel.value === o.v ? ' is-on' : '' ) + '" data-v="' + esc( o.v ) + '"' + ( live.has( o.v ) ? '' : ' disabled' ) + '>' + ( hex( o.t ) ? '<i style="--c:' + hex( o.t ) + '"></i>' : '' ) + esc( o.t ) + '</button>' ).join( '' );
			};
			wrap.addEventListener( 'click', ( e ) => {
				const b = e.target.closest( '.bs-swatch' );
				if ( ! b || b.disabled ) return;
				sel.value = b.dataset.v;
				jq( sel ).trigger( 'change' );
			} );
			sel.classList.add( 'bs-swatch-select' );
			sel.after( wrap );
			paint();
			jq( sel.form ).on( 'woocommerce_update_variation_values woocommerce_variation_has_changed reset_data', () => setTimeout( paint, 0 ) );
		} );
	}

	/* Free-delivery bar and promo codes ---------------------------------- */
	function renderBar( total ) {
		const left = Math.max( 0, freeAt - total );
		const pct = Math.min( 100, Math.round( ( total / freeAt ) * 100 ) );
		const msg = left > 0
			? 'Add <strong>' + fmt( left ) + '</strong> more for <strong>free Nairobi delivery</strong>'
			: '<strong>You\'ve unlocked free Nairobi delivery! 🌿</strong>';
		$$( '[data-bs-freebar]' ).forEach( ( el ) => {
			el.innerHTML = msg + '<div class="bs-freebar__track"><div class="bs-freebar__fill" style="width:' + pct + '%"></div></div>';
		} );
	}
	function watchCart() {
		const wpData = window.wp && window.wp.data;
		if ( ! wpData || ! wpData.select( 'wc/store/cart' ) ) return;
		let last = null;
		let codes = null;
		wpData.subscribe( () => {
			const store = wpData.select( 'wc/store/cart' );
			const totals = store.getCartTotals();
			if ( totals && totals.total_items !== undefined ) {
				const sub = money( totals.total_items, totals );
				if ( sub !== last ) {
					last = sub;
					renderBar( sub );
				}
			}
			const now = ( store.getCartData().coupons || [] ).map( ( c ) => c.code );
			if ( codes !== null ) now.filter( ( c ) => ! codes.includes( c ) ).forEach( ( c ) => toast( '✓ Promo code <strong>' + esc( c.toUpperCase() ) + '</strong> applied' ) );
			if ( store.hasFinishedResolution && store.hasFinishedResolution( 'getCartData' ) ) codes = now;
		} );
	}

	/* Plant matcher ------------------------------------------------------ */
	const LIGHT = { 'low-light': 'Happy in low light', 'bright-indirect': 'Bright, indirect light', 'full-sun': 'Loves full sun' };
	const WATER = { rarely: 'Water every 1–3 weeks', weekly: 'Water about weekly', often: 'Water 2–3× a week' };
	function match( answers ) {
		const want = { low: [ 'low-light' ], bright: [ 'bright-indirect', 'low-light' ], sunny: [ 'full-sun' ], garden: [ 'full-sun' ] }[ answers.where ];
		const pool = data().filter( ( p ) => ! p.made && p.inStock && ( answers.pets !== 'yes' || p.pets.includes( 'pet-safe' ) ) );
		const score = ( p ) => {
			let s = 0;
			if ( answers.where === 'garden' && p.space.includes( 'garden' ) ) s += 3;
			if ( answers.where === 'sunny' && ( p.space.includes( 'balcony' ) || p.space.includes( 'hanging' ) ) ) s += 3;
			if ( ( answers.where === 'low' || answers.where === 'bright' ) && p.space.includes( 'indoor' ) ) s += 3;
			if ( answers.where === 'low' && p.light.includes( 'low-light' ) ) s += 1;
			if ( answers.care === 'low' ) s += ( p.water.includes( 'rarely' ) ? 3 : p.water.includes( 'weekly' ) ? 1 : -3 ) + ( p.level.includes( 'beginner' ) ? 1 : 0 );
			if ( answers.care === 'some' && ! p.water.includes( 'often' ) ) s += 1;
			if ( answers.care === 'lots' && p.cat.includes( 'flowering-plants' ) ) s += 2;
			return s;
		};
		let hits = pool.filter( ( p ) => p.light.some( ( l ) => want.includes( l ) ) );
		let relaxed = false;
		if ( ! hits.length ) {
			hits = pool;
			relaxed = true;
		}
		hits = hits.map( ( p ) => ( { p, s: score( p ) } ) ).filter( ( h ) => answers.care !== 'low' || h.s > -2 ).sort( ( a, b ) => b.s - a.s ).slice( 0, 6 ).map( ( h ) => h.p );
		return { hits, relaxed };
	}
	function initMatcher() {
		$$( '[data-bs-matcher]' ).forEach( ( form ) => {
			const out = form.querySelector( '[data-bs-match-out]' );
			const run = ( announce ) => {
				const f = new FormData( form );
				const answers = { where: f.get( 'where' ), pets: f.get( 'pets' ), care: f.get( 'care' ) };
				const { hits, relaxed } = match( answers );
				if ( ! hits.length ) {
					out.innerHTML = '<div class="bs-match__none"><p>Nothing we have in right now fits all three. Tell us about your space and we\'ll suggest something from the greenhouse.</p><a class="wp-element-button bs-wa-btn" target="_blank" rel="noopener" href="' + esc( waLink( 'Hi Bloem Sefa, I\'m looking for a plant. Where it will live: , pets: , how much care I can give: ' ) ) + '">Ask us on WhatsApp</a></div>';
					return;
				}
				out.innerHTML = '<p class="bs-match__count"><strong>' + hits.length + ' plant' + ( hits.length > 1 ? 's' : '' ) + ' for you</strong>' + ( relaxed ? ' · the closest we have in right now' : '' ) + '</p><div class="bs-match__grid">' + hits.map( ( p ) => {
					const why = [];
					if ( p.pets.includes( 'pet-safe' ) ) why.push( '🐾 Pet-safe' );
					const l = p.light.find( ( x ) => LIGHT[ x ] );
					if ( l ) why.push( ( l === 'full-sun' ? '☀️ ' : '🌤️ ' ) + LIGHT[ l ] );
					if ( p.water[ 0 ] ) why.push( '💧 ' + WATER[ p.water[ 0 ] ] );
					if ( p.level.includes( 'beginner' ) ) why.push( '🌱 Beginner friendly' );
					return '<article class="bs-match__card"><a href="' + esc( p.url ) + '" class="bs-match__img">' + ( p.imgs[ 0 ] ? '<img src="' + esc( p.imgs[ 0 ].thumb ) + '" alt="" loading="lazy">' : '' ) + '</a><div><h3><a href="' + esc( p.url ) + '">' + esc( p.name ) + '</a></h3><p class="bs-match__price">' + fromPrice( p ) + '</p><ul>' + why.map( ( w ) => '<li>' + esc( w ) + '</li>' ).join( '' ) + '</ul>' + buyButton( p ) + '</div></article>';
				} ).join( '' ) + '</div>';
				if ( announce ) toast( '🌿 ' + hits.length + ' plants match your space' );
			};
			form.addEventListener( 'change', () => run( false ) );
			run( false );
		} );
	}

	/* Pop-ups: countdown and map --------------------------------------------- */
	function initPopups() {
		$$( '[data-bs-countdown]' ).forEach( ( el ) => {
			const at = new Date( el.dataset.bsCountdown + 'T09:00:00+03:00' ).getTime();
			const tick = () => {
				const left = Math.max( 0, at - Date.now() );
				el.querySelector( '[data-d]' ).textContent = Math.floor( left / 864e5 );
				el.querySelector( '[data-h]' ).textContent = Math.floor( ( left % 864e5 ) / 36e5 );
				el.querySelector( '[data-m]' ).textContent = Math.floor( ( left % 36e5 ) / 6e4 );
			};
			tick();
			setInterval( tick, 30000 );
		} );
		document.addEventListener( 'click', ( e ) => {
			const b = e.target.closest( '[data-bs-map]' );
			if ( ! b ) return;
			const wrap = b.closest( '.bs-popups__history' );
			const frame = wrap && wrap.querySelector( '[data-bs-map-frame]' );
			$$( '.bs-pop', wrap ).forEach( ( li ) => {
				const on = li.contains( b );
				li.classList.toggle( 'is-on', on );
				li.querySelector( 'button' ).setAttribute( 'aria-pressed', on ? 'true' : 'false' );
			} );
			if ( ! frame ) return;
			const cap = wrap.querySelector( '[data-bs-map-caption]' );
			if ( b.dataset.bsMap ) {
				frame.src = 'https://maps.google.com/maps?q=' + encodeURIComponent( b.dataset.bsMap ) + '&z=14&output=embed';
				frame.title = 'Map: ' + b.dataset.bsMapTitle;
				if ( cap ) cap.textContent = b.dataset.bsMapTitle;
			} else if ( cap ) {
				cap.textContent = b.dataset.bsMapTitle + ' (exact venue not on the map)';
			}
		} );
	}

	/* Plant Club and garden centre sign-ups -------------------------------- */
	function initSignups() {
		$$( '[data-bs-signup]' ).forEach( ( form ) => {
			form.addEventListener( 'submit', async ( e ) => {
				e.preventDefault();
				const f = new FormData( form );
				const body = { type: form.dataset.type, name: f.get( 'name' ), phone: f.get( 'phone' ), website: f.get( 'website' ), interests: f.getAll( 'interests' ) };
				const btn = form.querySelector( 'button[type=submit]' );
				const ok = form.querySelector( '[data-bs-signup-ok]' );
				btn.disabled = true;
				try {
					const res = await fetch( cfg.signup, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify( body ) } );
					const out = await res.json();
					if ( ! res.ok ) throw new Error( out.message || 'Please check your details.' );
					const garden = form.dataset.type === 'garden';
					const msg = garden ? 'Hi Bloem Sefa, I\'m ' + body.name + '. Please let me know when the Karen Garden Centre opens' + ( body.interests.length ? ' (interested in: ' + body.interests.join( ', ' ) + ')' : '' ) + '.' : 'Hi Bloem Sefa, I\'m ' + body.name + '. Please add me to the Plant Club for pop-up dates and care tips 🌱';
					ok.innerHTML = '🌱 Thank you, ' + esc( body.name ) + '! ' + ( garden ? 'You\'ll be first to hear when the garden centre opens.' : 'You\'re in the Plant Club.' ) + ( out.static ? ' <a href="' + esc( waLink( msg ) ) + '" target="_blank" rel="noopener">Send it to us on WhatsApp</a> to confirm.' : '' );
					ok.hidden = false;
					form.querySelectorAll( 'input:not([type=checkbox]):not(.bs-hp)' ).forEach( ( i ) => ( i.value = '' ) );
					toast( '🌱 You\'re on the list' );
				} catch ( err ) {
					toast( esc( err.message ) );
				} finally {
					btn.disabled = false;
				}
			} );
		} );
	}

	/* Announcement bar: one message at a time -------------------------------- */
	function initAnnounce() {
		const items = $$( '.bs-announce__item' );
		if ( items.length < 2 || matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) return;
		let i = 0;
		setInterval( () => {
			items[ i ].classList.remove( 'is-on' );
			i = ( i + 1 ) % items.length;
			items[ i ].classList.add( 'is-on' );
		}, 4500 );
	}

	function init() {
		initAnnounce();
		paintWish();
		renderWishlist();
		initSearch();
		initSwatches();
		initProductOptions();
		initMatcher();
		initPopups();
		initSignups();
		watchCart();
		// Cards re-render client-side in some blocks; keep hearts in sync.
		new MutationObserver( () => paintWish() ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', init );
	else init();
} )();
