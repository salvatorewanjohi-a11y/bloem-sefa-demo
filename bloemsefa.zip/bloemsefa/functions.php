<?php
/**
 * Bloem Sefa child theme.
 */

const BS_FREE_DELIVERY = 5000; // KSh, keep in step with the "Free Nairobi delivery" shipping method. PLACEHOLDER.
const BS_WHATSAPP      = ''; // PLACEHOLDER: Bloem Sefa's WhatsApp number as 2547XXXXXXXX. Empty = WhatsApp asks which chat to send to.
const BS_INSTAGRAM     = 'https://www.instagram.com/bloemsefa/';
const BS_IG_DM         = 'https://ig.me/m/bloemsefa';
const BS_FONTS         = 'https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400;1,9..144,500&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&display=swap';
const BS_FILTERS       = [ 'light' => 'Light', 'space' => 'Space', 'pets' => 'Pets', 'care' => 'Care' ];
const BS_BUDGETS       = [ [ 'Under KSh 500', 0, 500 ], [ 'KSh 500 – 1,000', 500, 1000 ], [ 'KSh 1,000+', 1000, 0 ] ];
const BS_LOW_STOCK     = 3;

// Pots and add-ons on every potted plant: key => [label, KSh, swatch colour]. PLACEHOLDER prices from the brief.
const BS_POTS = [
	'grower'     => [ 'Grower\'s pot', 0, '#2F2F2C' ],
	'terracotta' => [ 'Terracotta', 600, '#C86428' ],
	'white'      => [ 'Matte white ceramic', 900, '#F1EEE6' ],
	'slate'      => [ 'Slate grey ceramic', 900, '#5D646B' ],
	'basket'     => [ 'Handwoven basket', 700, '#B8925A' ],
];
const BS_EXTRAS = [
	'food'   => [ 'Organic plant food & soil mix', 800, 'A bag of our potting mix with slow-release organic feed, for repotting.' ],
	'saucer' => [ 'Ceramic saucer', 500, 'Catches drips under the pot.' ],
	'gift'   => [ 'Gift wrap & hand-written card', 300, 'Wrapped in kraft paper with a card in our handwriting.' ],
];

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'bs-fonts', BS_FONTS, [], null );
	wp_enqueue_style( 'bs', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'bs', $uri . '/assets/bs.js', [], filemtime( $dir . '/assets/bs.js' ), true );
	wp_localize_script( 'bs', 'BS', [
		'freeAt' => BS_FREE_DELIVERY,
		'store'  => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'signup' => esc_url_raw( rest_url( 'bs/v1/signup' ) ),
		'shop'   => esc_url_raw( wc_get_page_permalink( 'shop' ) ),
		'cart'   => esc_url_raw( wc_get_cart_url() ),
		'home'   => esc_url_raw( home_url( '/' ) ),
		'wa'     => BS_WHATSAPP,
		'ig'     => BS_IG_DM,
		'pots'   => BS_POTS,
		'extras' => BS_EXTRAS,
	] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'bs-fonts', BS_FONTS, [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

function bs_wa_link( $text = '' ) {
	// Product names can carry HTML entities (e.g. &amp;); WhatsApp needs the plain text.
	$text = $text !== '' ? 'text=' . rawurlencode( html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) : '';
	return BS_WHATSAPP ? 'https://wa.me/' . BS_WHATSAPP . ( $text ? "?$text" : '' ) : 'https://wa.me/?' . $text;
}
function bs_money( $n ) {
	return 'KSh ' . number_format( (float) $n );
}

const BS_WA_ICON = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.3 0 .5l-.4.6-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.7-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.2Z"/></svg>';
const BS_IG_ICON = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r=".6" fill="currentColor"/></svg>';
const BS_HEART   = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg>';

/* -------------------------------------------------------------------------
 * Plant data: care sheet, tags and options
 * ---------------------------------------------------------------------- */

const BS_CARE_ROWS = [ 'light' => 'Light', 'water' => 'Watering', 'feed' => 'Feeding', 'repot' => 'Repotting & tips', 'pets' => 'Pets & toxicity' ];

function bs_care( $product_id ) {
	$out = [];
	foreach ( BS_CARE_ROWS as $key => $label ) {
		$v = trim( (string) get_post_meta( $product_id, "_bs_care_$key", true ) );
		if ( $v !== '' ) $out[ $key ] = [ $label, $v ];
	}
	return $out;
}

// Filter terms (light, space, pets, care, water) for a product, in the store's order.
function bs_tags( $product_id, $attr ) {
	$terms = wp_get_post_terms( $product_id, wc_attribute_taxonomy_name( $attr ) );
	if ( is_wp_error( $terms ) ) {
		return [];
	}
	usort( $terms, fn( $a, $b ) => (int) get_term_meta( $a->term_id, 'order', true ) <=> (int) get_term_meta( $b->term_id, 'order', true ) );
	return $terms;
}
function bs_tag_slugs( $product_id, $attr ) {
	return wp_list_pluck( bs_tags( $product_id, $attr ), 'slug' );
}
function bs_has_pots( $product_id ) {
	return get_post_meta( $product_id, '_bs_pots', true ) === 'yes';
}
function bs_is_made( $product_id ) {
	return get_post_meta( $product_id, '_bs_made', true ) === 'yes';
}

// Colour names on cards and swatches.
const BS_COLOURS = [
	'red' => '#C8102E', 'scarlet' => '#D2122E', 'ruby' => '#9B111E', 'christmas' => '#C8102E', 'yellow' => '#F4C430', 'sunshine' => '#F6C324',
	'butter' => '#F3E18A', 'hot pink' => '#E0218A', 'blush' => '#F4A6B7', 'soft pink' => '#F7B5C4', 'pink star' => '#D6337F', 'pink' => '#EE7FA4',
	'orange' => '#F28C28', 'coral' => '#F2706B', 'salmon' => '#F59A80', 'rose' => '#D9467A', 'white' => '#FAFAF5', 'snow' => '#FFFFFF', 'cream' => '#F1E9C6',
	'burgundy' => '#5B1027', 'lilac' => '#B9A2D8', 'purple & magenta' => '#7A1F86', 'purple' => '#6B2E8F',
];
function bs_colour( $name ) {
	$n = strtolower( $name );
	foreach ( BS_COLOURS as $key => $hex ) {
		if ( str_contains( $n, $key ) ) return $hex;
	}
	return '';
}

/** Cleans submitted pot and add-on choices against what the plant offers. */
function bs_clean_options( $raw, $product_id ) {
	$raw = is_array( $raw ) ? $raw : [];
	$out = [];
	$pots = bs_has_pots( $product_id );
	$pot  = (string) ( $raw['pot'] ?? 'grower' );
	if ( $pots && isset( BS_POTS[ $pot ] ) && $pot !== 'grower' ) $out['pot'] = $pot;
	$allowed = $pots ? array_keys( BS_EXTRAS ) : [ 'gift' ];
	$ex      = array_values( array_intersect( (array) ( $raw['extras'] ?? [] ), $allowed ) );
	if ( $ex ) $out['extras'] = $ex;
	$card = trim( sanitize_textarea_field( (string) ( $raw['card'] ?? '' ) ) );
	if ( $card !== '' && in_array( 'gift', $ex, true ) ) $out['card'] = mb_substr( $card, 0, 200 );
	return $out;
}

/** What the pot and add-ons add to one plant's price. */
function bs_options_cost( array $o ) {
	$add = BS_POTS[ $o['pot'] ?? 'grower' ][1] ?? 0;
	foreach ( $o['extras'] ?? [] as $e ) {
		$add += BS_EXTRAS[ $e ][1] ?? 0;
	}
	return $add;
}

/** The choices as label => value lines, for the cart, the order and WhatsApp. */
function bs_options_lines( array $o ) {
	$out = [];
	if ( ! empty( $o['pot'] ) ) $out['Pot'] = BS_POTS[ $o['pot'] ][0] . ' +' . bs_money( BS_POTS[ $o['pot'] ][1] );
	if ( ! empty( $o['extras'] ) ) $out['Add-ons'] = implode( ', ', array_map( fn( $e ) => BS_EXTRAS[ $e ][0] . ' +' . bs_money( BS_EXTRAS[ $e ][1] ), $o['extras'] ) );
	if ( ! empty( $o['card'] ) ) $out['Card message'] = $o['card'];
	return $out;
}

// Product page form (classic POST "bs[...]") and the Store API (quick view sends "bs": {...}).
add_filter( 'woocommerce_add_cart_item_data', function ( $data, $product_id ) {
	if ( isset( $data['bs'] ) ) {
		return $data;
	}
	$opts = bs_clean_options( isset( $_POST['bs'] ) ? wp_unslash( $_POST['bs'] ) : [], $product_id ); // phpcs:ignore
	if ( $opts ) $data['bs'] = $opts;
	return $data;
}, 10, 2 );
add_filter( 'woocommerce_store_api_add_to_cart_data', function ( $data, $request ) {
	$product   = wc_get_product( $data['id'] );
	$parent_id = $product && $product->get_parent_id() ? $product->get_parent_id() : (int) $data['id'];
	$opts      = bs_clean_options( $request['bs'] ?? [], $parent_id );
	if ( $opts ) {
		$data['cart_item_data']       = $data['cart_item_data'] ?? [];
		$data['cart_item_data']['bs'] = $opts;
	}
	return $data;
}, 10, 2 );
add_action( 'woocommerce_before_calculate_totals', function ( $cart ) {
	foreach ( $cart->get_cart() as $item ) {
		if ( empty( $item['bs'] ) ) continue;
		$base = wc_get_product( $item['variation_id'] ?: $item['product_id'] );
		if ( $base ) $item['data']->set_price( (float) $base->get_price() + bs_options_cost( $item['bs'] ) );
	}
}, 20 );
add_filter( 'woocommerce_get_item_data', function ( $rows, $item ) {
	foreach ( bs_options_lines( $item['bs'] ?? [] ) as $k => $v ) {
		$rows[] = [ 'key' => $k, 'value' => $v ];
	}
	return $rows;
}, 10, 2 );
add_action( 'woocommerce_checkout_create_order_line_item', function ( $line, $key, $values ) {
	foreach ( bs_options_lines( $values['bs'] ?? [] ) as $k => $v ) {
		$line->add_meta_data( $k, $v );
	}
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Product page
 * ---------------------------------------------------------------------- */

add_filter( 'woocommerce_product_single_add_to_cart_text', fn() => 'Add to cart' );
// Card buttons on plants with colours or packs open the quick view (bs.js).
add_filter( 'woocommerce_product_add_to_cart_text', function ( $text, $product ) {
	if ( ! $product || ! $product->is_type( 'variable' ) || ! $product->is_in_stock() ) return $text;
	$attr = array_key_first( $product->get_variation_attributes() );
	return 'Choose ' . strtolower( wc_attribute_label( $attr ) );
}, 10, 2 );
add_filter( 'woocommerce_get_availability_text', function ( $text, $product ) {
	if ( ! $product->is_in_stock() ) return 'Sold out for now – ask us when the next batch is ready';
	$id = $product->get_parent_id() ?: $product->get_id();
	if ( bs_is_made( $id ) ) return 'Made to order in our greenhouse';
	return $product->managing_stock() && (int) $product->get_stock_quantity() <= BS_LOW_STOCK ? 'Only ' . (int) $product->get_stock_quantity() . ' left in this batch' : 'In stock · grown by us';
}, 10, 2 );

// Plant tags and the four care facts above the add-to-cart button.
add_action( 'woocommerce_before_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$id   = $product->get_id();
	$tags = array_merge( bs_tags( $id, 'care' ), bs_tags( $id, 'pets' ), bs_tags( $id, 'light' ) );
	if ( $tags ) {
		echo '<div class="bs-tags">';
		foreach ( $tags as $t ) {
			$attr = str_replace( 'pa_', '', $t->taxonomy );
			echo '<a class="bs-tag bs-tag--' . esc_attr( $attr ) . '" href="' . esc_url( add_query_arg( "filter_$attr", $t->slug, wc_get_page_permalink( 'shop' ) ) ) . '">' . esc_html( $t->name ) . '</a>';
		}
		echo '</div>';
	}
	$water = bs_tags( $id, 'water' );
	$light = bs_tags( $id, 'light' );
	$facts = array_filter( [
		'☀️ Light'    => implode( ' or ', wp_list_pluck( $light, 'name' ) ),
		'💧 Water'    => $water ? $water[0]->name : '',
		'🐾 Pets'     => in_array( 'pet-safe', bs_tag_slugs( $id, 'pets' ), true ) ? 'Safe for cats & dogs' : 'Keep out of reach',
		'🌱 Grown by' => bs_is_made( $id ) ? 'Hand-made to order' : 'Us, in our greenhouse',
	] );
	echo '<ul class="bs-keyfacts">';
	foreach ( $facts as $k => $v ) {
		echo '<li><span>' . esc_html( $k ) . '</span><strong>' . esc_html( $v ) . '</strong></li>';
	}
	echo '</ul>';
	if ( bs_is_made( $id ) ) {
		echo '<p class="bs-note">🗓️ <strong>Made to order.</strong> Add the date you need it in the order note at checkout and we\'ll confirm when it will be ready.</p>';
	}
} );

// Pot choice and add-ons, inside the form so they're sent with the plant.
add_action( 'woocommerce_before_add_to_cart_button', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	echo bs_options_html( $product->get_id() ); // phpcs:ignore
} );

function bs_options_html( $product_id ) {
	$pots = bs_has_pots( $product_id );
	$h    = '<div class="bs-options" data-bs-options>';
	if ( $pots ) {
		$h .= '<fieldset class="bs-pots"><legend>Pot <span data-bs-pot-name>Grower\'s pot</span></legend><div class="bs-pots__row">';
		foreach ( BS_POTS as $key => [ $label, $price, $hex ] ) {
			$h .= sprintf(
				'<label class="bs-pot" title="%1$s"><input type="radio" name="bs[pot]" value="%2$s" data-price="%3$d" data-label="%1$s"%4$s><span class="bs-pot__swatch" style="--pot:%5$s" aria-hidden="true"></span><span class="bs-pot__txt">%1$s<em>%6$s</em></span></label>',
				esc_attr( $label ), esc_attr( $key ), $price, $key === 'grower' ? ' checked' : '', esc_attr( $hex ), $price ? '+' . esc_html( bs_money( $price ) ) : 'Included'
			);
		}
		$h .= '</div></fieldset>';
	}
	$h .= '<fieldset class="bs-extras"><legend>Add-ons</legend>';
	foreach ( BS_EXTRAS as $key => [ $label, $price, $hint ] ) {
		if ( ! $pots && $key !== 'gift' ) continue;
		$h .= sprintf(
			'<label class="bs-extra"><input type="checkbox" name="bs[extras][]" value="%1$s" data-price="%2$d"><span><strong>%3$s</strong><em>%4$s</em></span><b>+%5$s</b></label>',
			esc_attr( $key ), $price, esc_html( $label ), esc_html( $hint ), esc_html( bs_money( $price ) )
		);
	}
	$h .= '<label class="bs-card" hidden data-bs-card><span>Your card message</span><textarea name="bs[card]" rows="2" maxlength="200" placeholder="e.g. Happy birthday Wanjiru! Love, Ken"></textarea></label>';
	$h .= '</fieldset><p class="bs-total" data-bs-total hidden>Your plant: <strong></strong></p></div>';
	return $h;
}

// Order on WhatsApp or Instagram, care sheet, promises and "complete the look" under the button.
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$price = $product->is_type( 'variable' ) ? 'from KSh ' . number_format( (float) $product->get_variation_price( 'min' ) ) : bs_money( $product->get_price() );
	$msg   = 'Hi Bloem Sefa, is the ' . $product->get_name() . ' (' . $price . ') available? ' . $product->get_permalink();
	echo '<div class="bs-order-alt"><a class="bs-wa-order" href="' . esc_url( bs_wa_link( $msg ) ) . '" target="_blank" rel="noopener">' . BS_WA_ICON . 'Order on WhatsApp</a><a class="bs-ig-order" href="' . esc_url( BS_IG_DM ) . '" target="_blank" rel="noopener">' . BS_IG_ICON . 'DM us on Instagram</a></div>';

	$care = bs_care( $product->get_id() );
	if ( $care ) {
		echo '<div class="bs-care"><p class="bs-care__title">Botanical care sheet</p>';
		foreach ( $care as $key => [ $label, $text ] ) {
			printf( '<details class="bs-care__row"%s><summary>%s</summary><p>%s</p></details>', $key === 'light' ? ' open' : '', esc_html( $label ), esc_html( $text ) );
		}
		echo '<p class="bs-care__ask">Not sure it suits your space? <a href="' . esc_url( home_url( '/plant-matcher/' ) ) . '">Try the plant matcher</a> or <a href="' . esc_url( bs_wa_link( 'Hi Bloem Sefa, will the ' . $product->get_name() . ' do well in my space? It gets ' ) ) . '" target="_blank" rel="noopener">ask us about your space</a>.</p></div>';
	}

	echo '<div class="bs-promise"><div><span aria-hidden="true">🌱</span><p><strong>Grown by us</strong>From our own greenhouse, sold in bloom so you see what you get.</p></div><div><span aria-hidden="true">🚲</span><p><strong>Nairobi delivery</strong>Riders across Nairobi and environs, or collect free at our next pop-up.</p></div><div><span aria-hidden="true">💬</span><p><strong>Care help after you buy</strong>Send us a photo any time and we\'ll tell you what your plant needs.</p></div></div>';

	$ids   = array_slice( $product->get_upsell_ids(), 0, 3 );
	$items = array_filter( array_map( 'wc_get_product', $ids ), fn( $p ) => $p && $p->is_visible() );
	if ( ! $items ) {
		return;
	}
	$simple = array_filter( $items, fn( $p ) => $p->is_in_stock() && $p->is_type( 'simple' ) );
	echo '<div class="bs-set"><p class="bs-set__title">Complete the look</p>';
	foreach ( $items as $p ) {
		printf(
			'<div class="bs-set__item"><a href="%s">%s</a><span><a href="%1$s"><strong>%s</strong></a>%s</span>%s</div>',
			esc_url( $p->get_permalink() ),
			$p->get_image( 'thumbnail' ),
			esc_html( $p->get_name() ),
			$p->get_price_html(),
			$p->is_in_stock() && $p->is_type( 'simple' ) ? '<button type="button" class="bs-set__add" data-bs-add="' . (int) $p->get_id() . '" aria-label="Add ' . esc_attr( $p->get_name() ) . ' to cart">+ Add</button>' : '<button type="button" class="bs-set__add" data-bs-qv="' . (int) $p->get_id() . '">Choose</button>'
		);
	}
	if ( $product->is_type( 'simple' ) && $product->is_in_stock() && $simple ) {
		$all   = array_merge( [ $product ], $simple );
		$total = array_sum( array_map( fn( $p ) => (float) $p->get_price(), $all ) );
		echo '<button type="button" class="bs-set__all" data-bs-add-many="' . esc_attr( implode( ',', array_map( fn( $p ) => $p->get_id(), $all ) ) ) . '">Add all ' . count( $all ) . ' to cart · ' . esc_html( bs_money( $total ) ) . '</button>';
	}
	echo '</div>';
} );

// "Complete the look" already shows next to the button.
add_action( 'init', function () {
	remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
} );

// Care sheet and delivery tabs.
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product ) {
		return $tabs;
	}
	$care = bs_care( $product->get_id() );
	if ( $care ) {
		$tabs['bs_care'] = [
			'title'    => 'Care sheet',
			'priority' => 5,
			'callback' => function () use ( $care ) {
				echo '<table class="bs-spec-table"><tbody>';
				foreach ( $care as [ $label, $text ] ) {
					echo '<tr><th>' . esc_html( $label ) . '</th><td>' . esc_html( $text ) . '</td></tr>';
				}
				echo '</tbody></table><p class="bs-small">General guidance for Nairobi homes and gardens. Every space is different: message us a photo of yours and we\'ll advise.</p>';
			},
		];
	}
	$tabs['bs_delivery'] = [
		'title'    => 'Delivery & pickup',
		'priority' => 40,
		'callback' => function () {
			echo '<ul><li><strong>Nairobi:</strong> our riders bring your plants upright and watered, KSh 300 to Karen, Lang\'ata and Ngong Road and KSh 500 to the rest of Nairobi. Free on orders over ' . esc_html( bs_money( BS_FREE_DELIVERY ) ) . '.</li><li><strong>Ngong, Rongai, Kiambu &amp; environs:</strong> KSh 800 by rider.</li><li><strong>Collect free at our next pop-up:</strong> we\'ll WhatsApp you the date and venue and keep your plants aside.</li><li><strong>Karen Garden Centre:</strong> pickup opens with the garden centre. <a href="' . esc_url( home_url( '/garden-centre/' ) ) . '">Get the opening date</a>.</li><li>Pay by M-Pesa or cash on delivery or at pickup.</li></ul>';
		},
	];
	if ( isset( $tabs['description'] ) ) {
		$tabs['description']['priority'] = 1;
		$tabs['description']['title']    = 'About this plant';
	}
	if ( isset( $tabs['reviews'] ) ) {
		$tabs['reviews']['title'] = str_replace( 'Reviews', 'Customer reviews', $tabs['reviews']['title'] );
	}
	unset( $tabs['additional_information'] );
	return $tabs;
}, 20 );

/* -------------------------------------------------------------------------
 * Product cards
 * ---------------------------------------------------------------------- */

function bs_card_product( $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	return $id && ! is_admin() ? wc_get_product( $id ) : null;
}

// Hover image (first gallery photo), card badge, wishlist heart and quick view on product images.
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$product = bs_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$gallery = $product->get_gallery_image_ids();
	if ( $gallery ) {
		$alt     = wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, [ 'class' => 'bs-alt-img', 'alt' => '', 'loading' => 'lazy' ] );
		$content = preg_replace( '#(<img[^>]*>)#', '$1' . $alt, $content, 1 );
	}
	$badge = get_post_meta( $product->get_id(), '_bs_badge', true );
	$extra = sprintf(
		'%4$s<button type="button" class="bs-heart" data-bs-wish="%1$d" aria-label="Save %2$s to wishlist" aria-pressed="false">%3$s</button><button type="button" class="bs-qv-btn" data-bs-qv="%1$d" aria-label="Quick view of %2$s">Quick view</button>',
		$product->get_id(),
		esc_attr( $product->get_name() ),
		BS_HEART,
		$badge ? '<span class="bs-badge-photo">' . esc_html( $badge ) . '</span>' : ''
	);
	$pos = strrpos( $content, '</div>' );
	return $pos === false ? $content : substr_replace( $content, $extra . '</div>', $pos, 6 );
}, 10, 3 );

// Plants with colours or packs show their lowest price, not a range.
add_filter( 'woocommerce_variable_price_html', function ( $html, $product ) {
	$min = $product->get_variation_price( 'min', true );
	if ( $min === $product->get_variation_price( 'max', true ) ) return $html;
	return '<span class="bs-from">From</span> ' . wc_price( $min );
}, 10, 2 );

// Care level and pet-safe tags above the price, colour dots and pot choices below it.
add_filter( 'render_block_woocommerce/product-price', function ( $content, $block, $instance ) {
	$product = bs_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$id     = $product->get_id();
	$before = '';
	foreach ( array_merge( bs_tags( $id, 'care' ), bs_tags( $id, 'pets' ) ) as $t ) {
		$before .= '<span class="bs-tag bs-tag--' . esc_attr( str_replace( 'pa_', '', $t->taxonomy ) ) . '">' . esc_html( $t->name ) . '</span>';
	}
	if ( ! $product->is_in_stock() ) {
		$before .= '<span class="bs-tag bs-tag--out">Sold out</span>';
	} elseif ( $product->managing_stock() && (int) $product->get_stock_quantity() <= BS_LOW_STOCK ) {
		$before .= '<span class="bs-tag bs-tag--low">Only ' . (int) $product->get_stock_quantity() . ' left</span>';
	}
	$after = '';
	if ( $product->is_type( 'variable' ) ) {
		$dots = '';
		foreach ( $product->get_variation_attributes() as $name => $values ) {
			foreach ( $values as $v ) {
				$hex = bs_colour( $v );
				if ( $hex ) $dots .= '<i style="--c:' . esc_attr( $hex ) . '" title="' . esc_attr( $v ) . '"></i>';
			}
		}
		if ( $dots ) $after .= '<button type="button" class="bs-dots" data-bs-qv="' . $id . '" aria-label="Choose a colour">' . $dots . '</button>';
	}
	if ( bs_has_pots( $id ) ) {
		$pots = '';
		foreach ( BS_POTS as [ $label, , $hex ] ) {
			$pots .= '<i style="--c:' . esc_attr( $hex ) . '" title="' . esc_attr( $label ) . '"></i>';
		}
		$after .= '<button type="button" class="bs-dots bs-dots--pots" data-bs-qv="' . $id . '" aria-label="Choose a pot">' . $pots . '<span>5 pot choices</span></button>';
	}
	return ( $before ? '<div class="bs-tags bs-tags--card">' . $before . '</div>' : '' ) . $content . ( $after ? '<div class="bs-card-opts">' . $after . '</div>' : '' );
}, 10, 3 );

// Sale badge shows the saving, e.g. "−20%".
add_filter( 'render_block_woocommerce/product-sale-badge', function ( $content, $block, $instance ) {
	$product = bs_card_product( $instance );
	if ( ! $product || ! $product->is_on_sale() || ! $product->is_type( 'simple' ) ) {
		return $content;
	}
	$reg  = (float) $product->get_regular_price();
	$sale = (float) $product->get_sale_price();
	$pct  = $reg > 0 && $sale > 0 ? round( ( $reg - $sale ) / $reg * 100 ) : 0;
	return $pct ? preg_replace( '#>\s*Sale\s*<#', '>−' . $pct . '%<', $content, 1 ) : $content;
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Plant data for the quick view, the plant matcher and the static copy
 * ---------------------------------------------------------------------- */

function bs_product_data() {
	static $data = null;
	if ( $data !== null ) {
		return $data;
	}
	$data = [];
	foreach ( wc_get_products( [ 'status' => 'publish', 'limit' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ] ) as $p ) {
		$id   = $p->get_id();
		$imgs = array_values( array_filter( array_map( fn( $a ) => $a ? [ 'src' => wp_get_attachment_image_url( $a, 'full' ), 'thumb' => wp_get_attachment_image_url( $a, 'woocommerce_thumbnail' ) ] : null, array_merge( [ $p->get_image_id() ], $p->get_gallery_image_ids() ) ) ) );
		$item = [
			'id'      => $id,
			'name'    => html_entity_decode( $p->get_name(), ENT_QUOTES | ENT_HTML5, 'UTF-8' ),
			'url'     => $p->get_permalink(),
			'type'    => $p->get_type(),
			'price'   => (float) $p->get_price(),
			'regular' => (float) $p->get_regular_price(),
			'short'   => wp_strip_all_tags( $p->get_short_description() ),
			'cat'     => wp_list_pluck( get_the_terms( $id, 'product_cat' ) ?: [], 'slug' ),
			'catName' => ( get_the_terms( $id, 'product_cat' ) ?: [ (object) [ 'name' => '' ] ] )[0]->name,
			'badge'   => (string) get_post_meta( $id, '_bs_badge', true ),
			'inStock' => $p->is_in_stock(),
			'pots'    => bs_has_pots( $id ),
			'made'    => bs_is_made( $id ),
			'imgs'    => $imgs,
			'care'    => array_values( bs_care( $id ) ),
			'light'   => bs_tag_slugs( $id, 'light' ),
			'space'   => bs_tag_slugs( $id, 'space' ),
			'water'   => bs_tag_slugs( $id, 'water' ),
			'level'   => bs_tag_slugs( $id, 'care' ),
			'pets'    => bs_tag_slugs( $id, 'pets' ),
			'attr'    => '',
			'vars'    => [],
		];
		if ( $p->is_type( 'variable' ) ) {
			$item['attr'] = wc_attribute_label( array_key_first( $p->get_variation_attributes() ) );
			foreach ( $p->get_children() as $vid ) {
				$v = wc_get_product( $vid );
				if ( ! $v || ! $v->is_purchasable() ) continue;
				$vals           = array_values( $v->get_attributes() );
				$item['vars'][] = [
					'id'      => $vid,
					'label'   => $vals[0] ?? '',
					'hex'     => bs_colour( $vals[0] ?? '' ),
					'price'   => (float) $v->get_price(),
					'regular' => (float) $v->get_regular_price(),
					'inStock' => $v->is_in_stock(),
					'img'     => wp_get_attachment_image_url( $v->get_image_id(), 'full' ) ?: '',
				];
			}
			$prices        = array_column( $item['vars'], 'price' );
			$item['price'] = $prices ? min( $prices ) : $item['price'];
		}
		$data[] = $item;
	}
	return $data;
}

// Quick view pop-up (filled in by bs.js) and the plant data it reads.
add_action( 'wp_footer', function () {
	if ( is_admin() ) return;
	echo '<dialog id="bs-qv" class="bs-dialog bs-qv" aria-label="Quick view"><form method="dialog"><button class="bs-dialog__close" aria-label="Close">×</button></form><div data-bs-qv-body></div></dialog>';
	echo '<script type="application/json" id="bs-data">' . wp_json_encode( bs_product_data() ) . '</script>';
} );

/* -------------------------------------------------------------------------
 * Home page and shop sections
 * ---------------------------------------------------------------------- */

function bs_categories() {
	$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}
function bs_filter_terms( $attr ) {
	$tax = wc_attribute_taxonomy_name( $attr );
	if ( ! taxonomy_exists( $tax ) ) {
		return [];
	}
	$terms = get_terms( [ 'taxonomy' => $tax, 'hide_empty' => true, 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}
function bs_count( $attr, $slug ) {
	$t = get_term_by( 'slug', $slug, wc_attribute_taxonomy_name( $attr ) );
	return $t ? (int) $t->count : 0;
}

// "Shop by space & care need": six tiles into the filtered shop.
const BS_SPACES = [
	[ 'Indoor & low light', 'Shady rooms, hallways and bathrooms', 'light', 'low-light', 'spider-plant' ],
	[ 'Pet-friendly plants', 'Safe for curious cats and dogs', 'pets', 'pet-safe', 'fuchsia' ],
	[ 'Balcony & sun lovers', 'Pots and boxes in full sun', 'space', 'balcony', '@balcony' ],
	[ 'Outdoor & landscape', 'Beds, borders and driveways', 'space', 'garden', '@garden' ],
	[ 'Office & desk', 'Small, easy, forgiving plants', 'space', 'office', 'echeveria-succulent' ],
	[ 'Flowering & gifts', 'Blooms, hearts and Christmas colour', 'space', 'gift', 'succulent-heart' ],
];
add_shortcode( 'bs_spaces', function () {
	$h = '<div class="bs-spaces">';
	foreach ( BS_SPACES as [ $title, $line, $attr, $slug, $img ] ) {
		if ( str_starts_with( $img, '@' ) ) {
			$pic = '<img src="' . esc_url( get_stylesheet_directory_uri() . '/assets/photos/' . substr( $img, 1 ) . '.webp' ) . '" alt="" loading="lazy" width="640" height="800">';
		} else {
			$p   = get_page_by_path( $img, OBJECT, 'product' );
			$pic = $p ? get_the_post_thumbnail( $p->ID, 'woocommerce_thumbnail', [ 'loading' => 'lazy', 'alt' => '' ] ) : '';
		}
		$n  = bs_count( $attr, $slug );
		$h .= sprintf(
			'<a class="bs-space" href="%s"><span class="bs-space__img">%s</span><span class="bs-space__txt"><strong>%s</strong><em>%s</em><small>%s →</small></span></a>',
			esc_url( add_query_arg( "filter_$attr", $slug, wc_get_page_permalink( 'shop' ) ) ),
			$pic,
			esc_html( $title ),
			esc_html( $line ),
			esc_html( sprintf( _n( '%d plant', '%d plants', $n ), $n ) )
		);
	}
	return $h . '</div>';
} );

// Photo links to products, e.g. [bs_photo_links items="succulent-heart|Succulent heart,poinsettia|Christmas poinsettia"].
add_shortcode( 'bs_photo_links', function ( $atts ) {
	$atts = shortcode_atts( [ 'items' => '', 'class' => '' ], $atts );
	$h    = '<div class="' . esc_attr( $atts['class'] ) . '">';
	foreach ( array_filter( explode( ',', $atts['items'] ) ) as $item ) {
		[ $slug, $label ] = array_pad( explode( '|', $item, 2 ), 2, '' );
		$p = get_page_by_path( trim( $slug ), OBJECT, 'product' );
		if ( ! $p ) continue;
		$h .= '<a href="' . esc_url( get_permalink( $p ) ) . '">' . get_the_post_thumbnail( $p->ID, 'full', [ 'loading' => 'lazy', 'alt' => get_the_title( $p ) ] ) . '<span>' . esc_html( $label ?: get_the_title( $p ) ) . '</span></a>';
	}
	return $h . '</div>';
} );

// A row of product cards from one category, e.g. [bs_collection cat="succulents" limit="8"].
// Built as a Product Collection block at render time, because the block needs the category's term id.
add_shortcode( 'bs_collection', function ( $atts ) {
	$atts = shortcode_atts( [ 'cat' => '', 'limit' => 8, 'columns' => 4 ], $atts );
	$term = get_term_by( 'slug', $atts['cat'], 'product_cat' );
	if ( ! $term ) {
		return '';
	}
	static $qid = 40;
	$query = [
		'perPage' => (int) $atts['limit'], 'pages' => 1, 'offset' => 0, 'postType' => 'product', 'order' => 'asc', 'orderBy' => 'menu_order',
		'search' => '', 'exclude' => [], 'inherit' => false, 'taxQuery' => [ 'product_cat' => [ $term->term_id ] ], 'isProductCollectionBlock' => true,
		'featured' => false, 'woocommerceOnSale' => false, 'woocommerceStockStatus' => [ 'instock', 'outofstock', 'onbackorder' ], 'woocommerceAttributes' => [], 'woocommerceHandPickedProducts' => [],
	];
	$attrs = [ 'queryId' => $qid++, 'query' => $query, 'tagName' => 'div', 'displayLayout' => [ 'type' => 'flex', 'columns' => (int) $atts['columns'], 'shrinkColumns' => true ], 'dimensions' => [ 'widthType' => 'fill' ], 'queryContextIncludes' => [ 'collection' ] ];
	return do_blocks( '<!-- wp:woocommerce/product-collection ' . wp_json_encode( $attrs ) . ' --><div class="wp-block-woocommerce-product-collection">' . BS_CARD . '</div><!-- /wp:woocommerce/product-collection -->' );
} );

// The product card used by every product grid.
const BS_CARD = '<!-- wp:woocommerce/product-template -->
<!-- wp:woocommerce/product-image {"showSaleBadge":false,"isDescendentOfQueryLoop":true,"aspectRatio":"4/5","scale":"cover"} -->
<!-- wp:woocommerce/product-sale-badge {"isDescendentOfQueryLoop":true,"align":"right"} /-->
<!-- /wp:woocommerce/product-image -->
<!-- wp:post-title {"level":3,"isLink":true,"style":{"spacing":{"margin":{"bottom":"0.2rem","top":"0.75rem"}},"typography":{"fontSize":"1.05rem","lineHeight":"1.3"}},"__woocommerceNamespace":"woocommerce/product-collection/product-title"} /-->
<!-- wp:woocommerce/product-price {"isDescendentOfQueryLoop":true,"fontSize":"medium"} /-->
<!-- wp:woocommerce/product-button {"isDescendentOfQueryLoop":true,"fontSize":"small"} /-->
<!-- /wp:woocommerce/product-template -->';

// The page being filtered, and the filter choices already in its address.
function bs_filter_state() {
	$current = get_queried_object();
	$base    = $current instanceof WP_Term ? get_term_link( $current ) : wc_get_page_permalink( 'shop' );
	$keep    = [];
	foreach ( array_merge( [ 'min_price', 'max_price', 'instock', 'orderby', 's', 'post_type' ], array_map( fn( $k ) => "filter_$k", array_keys( BS_FILTERS ) ) ) as $key ) {
		if ( isset( $_GET[ $key ] ) && $_GET[ $key ] !== '' ) {
			$keep[ $key ] = sanitize_text_field( wp_unslash( $_GET[ $key ] ) );
		}
	}
	return [ $current, is_wp_error( $base ) ? wc_get_page_permalink( 'shop' ) : $base, $keep ];
}

// Category chips, then light, space, pets, care and budget rows, above shop, category and search results.
add_shortcode( 'bs_filters', function () {
	global $wpdb;
	[ $current, $base, $keep ] = bs_filter_state();
	$cur_id = $current instanceof WP_Term ? $current->term_id : 0;
	$link   = fn( $args ) => esc_url( add_query_arg( $args, $base ) );

	$h  = '<nav class="bs-filters" aria-label="Filter plants"><div class="bs-filters__row bs-filters__row--cats">';
	$h .= '<a class="bs-chip' . ( is_shop() && ! is_search() ? ' is-on' : '' ) . '" href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '">All plants</a>';
	foreach ( bs_categories() as $t ) {
		$h .= sprintf( '<a class="bs-chip%s" href="%s">%s <em>%d</em></a>', $t->term_id === $cur_id ? ' is-on' : '', esc_url( get_term_link( $t ) ), esc_html( $t->name ), (int) $t->count );
	}
	$h .= '</div>';

	foreach ( BS_FILTERS as $attr => $label ) {
		$chosen = $keep[ "filter_$attr" ] ?? '';
		$row    = '';
		foreach ( bs_filter_terms( $attr ) as $t ) {
			$on   = $chosen === $t->slug;
			$args = $on ? array_diff_key( $keep, [ "filter_$attr" => 1 ] ) : array_merge( $keep, [ "filter_$attr" => $t->slug ] );
			$row .= sprintf( '<a class="bs-chip bs-chip--sm%s" href="%s" rel="nofollow">%s</a>', $on ? ' is-on' : '', $link( $args ), esc_html( $t->name ) );
		}
		if ( $row ) $h .= '<div class="bs-filters__row"><span class="bs-filters__label">' . esc_html( $label ) . '</span>' . $row . '</div>';
	}

	// Budget, plus the in-stock switch.
	$h .= '<div class="bs-filters__row"><span class="bs-filters__label">Budget</span>';
	foreach ( BS_BUDGETS as [ $label, $min, $max ] ) {
		$on   = ( isset( $keep['min_price'] ) || isset( $keep['max_price'] ) ) && (int) ( $keep['min_price'] ?? 0 ) === $min && (int) ( $keep['max_price'] ?? 0 ) === $max;
		$args = array_diff_key( $keep, [ 'min_price' => 1, 'max_price' => 1 ] );
		if ( ! $on ) {
			$args = array_merge( $args, array_filter( [ 'min_price' => $min, 'max_price' => $max ] ) );
		}
		$h .= sprintf( '<a class="bs-chip bs-chip--sm%s" href="%s" rel="nofollow">%s</a>', $on ? ' is-on' : '', $link( $args ), esc_html( $label ) );
	}
	$stock_on = ! empty( $keep['instock'] );
	$h       .= sprintf( '<a class="bs-switch%s" href="%s" rel="nofollow" role="switch" aria-checked="%s"><span></span>In stock only</a>', $stock_on ? ' is-on' : '', $link( $stock_on ? array_diff_key( $keep, [ 'instock' => 1 ] ) : array_merge( $keep, [ 'instock' => '1' ] ) ), $stock_on ? 'true' : 'false' );
	$h       .= '</div>';

	$active = count( array_diff_key( $keep, array_flip( [ 'orderby', 's', 'post_type' ] ) ) );
	$h     .= '<div class="bs-filters__foot">';
	if ( $active ) {
		$h .= '<a class="bs-filters__clear" href="' . esc_url( add_query_arg( array_intersect_key( $keep, array_flip( [ 'orderby', 's', 'post_type' ] ) ), $base ) ) . '">✕ Clear filters</a>';
	}
	return $h . '<a class="bs-filters__matcher" href="' . esc_url( home_url( '/plant-matcher/' ) ) . '">Not sure? Let the plant matcher choose →</a></div></nav>';
} );

// "In stock only" switch on shop pages.
add_action( 'woocommerce_product_query', function ( $q ) {
	if ( ! empty( $_GET['instock'] ) ) {
		$meta   = (array) $q->get( 'meta_query' );
		$meta[] = [ 'key' => '_stock_status', 'value' => 'instock' ];
		$q->set( 'meta_query', $meta );
	}
} );
add_filter( 'query_loop_block_query_vars', function ( $vars ) {
	if ( ! empty( $_GET['instock'] ) && ( $vars['post_type'] ?? '' ) === 'product' ) {
		$vars['meta_query']   = (array) ( $vars['meta_query'] ?? [] );
		$vars['meta_query'][] = [ 'key' => '_stock_status', 'value' => 'instock' ];
	}
	return $vars;
} );

add_shortcode( 'bs_wishlist', function () {
	return '<div class="bs-wishlist" data-bs-wishlist><p class="bs-small">Loading your saved plants…</p></div>';
} );

/* -------------------------------------------------------------------------
 * Plant matcher
 * ---------------------------------------------------------------------- */

// Three questions; bs.js scores every plant in #bs-data against the answers.
add_shortcode( 'bs_matcher', function ( $atts ) {
	$atts = shortcode_atts( [ 'compact' => '' ], $atts );
	$q    = fn( $name, $title, $opts ) => '<fieldset class="bs-match__q"><legend>' . $title . '</legend><div class="bs-match__opts">' . implode( '', array_map( fn( $o ) => '<label><input type="radio" name="' . $name . '" value="' . $o[0] . '"' . ( ! empty( $o[3] ) ? ' checked' : '' ) . '><span><b aria-hidden="true">' . $o[1] . '</b>' . $o[2] . '</span></label>', $opts ) ) . '</div></fieldset>';
	return '<form class="bs-match' . ( $atts['compact'] ? ' bs-match--compact' : '' ) . '" data-bs-matcher onsubmit="return false">'
		. '<div class="bs-match__qs">'
		. $q( 'where', '1. Where will it live?', [ [ 'low', '🛋️', 'Indoors, away from windows', true ], [ 'bright', '🪟', 'Indoors, by a bright window' ], [ 'sunny', '☀️', 'Balcony or patio with sun' ], [ 'garden', '🌳', 'In the garden' ] ] )
		. $q( 'pets', '2. Cats or dogs at home?', [ [ 'yes', '🐾', 'Yes – pet-safe only', true ], [ 'no', '🚫', 'No pets' ] ] )
		. $q( 'care', '3. How much time for plant care?', [ [ 'low', '🌵', 'I forget to water', true ], [ 'some', '💧', 'Happy to water weekly' ], [ 'lots', '🌸', 'I love gardening' ] ] )
		. '</div><div class="bs-match__out" data-bs-match-out aria-live="polite"></div></form>';
} );

/* -------------------------------------------------------------------------
 * Pop-up markets and the Karen Garden Centre
 * ---------------------------------------------------------------------- */

add_action( 'init', function () {
	register_post_type( 'bs_popup', [
		'labels'       => [ 'name' => 'Pop-ups', 'singular_name' => 'Pop-up', 'add_new_item' => 'Add pop-up market', 'edit_item' => 'Edit pop-up market', 'menu_name' => 'Pop-ups' ],
		'public'       => false,
		'show_ui'      => true,
		'menu_icon'    => 'dashicons-store',
		'menu_position' => 56,
		'supports'     => [ 'title', 'editor' ],
	] );
	register_post_type( 'bs_signup', [
		'labels'        => [ 'name' => 'Plant Club sign-ups', 'singular_name' => 'Sign-up', 'menu_name' => 'Plant Club' ],
		'public'        => false,
		'show_ui'       => true,
		'menu_icon'     => 'dashicons-groups',
		'menu_position' => 57,
		'supports'      => [ 'title', 'editor' ],
		'capabilities'  => [ 'create_posts' => 'do_not_allow' ],
		'map_meta_cap'  => true,
	] );
} );

const BS_POPUP_FIELDS = [
	'date'  => [ 'Start date', 'date', '' ],
	'end'   => [ 'End date (optional)', 'date', '' ],
	'label' => [ 'Date shown instead (optional)', 'text', 'e.g. "November 2023" when the exact day isn\'t known' ],
	'time'  => [ 'Opening hours (optional)', 'text', 'e.g. 9 AM – 5 PM' ],
	'venue' => [ 'Venue', 'text', 'e.g. Sarit Expo Centre' ],
	'area'  => [ 'Area', 'text', 'e.g. Westlands' ],
	'map'   => [ 'Google Maps search', 'text', 'What to search on Google Maps for directions, e.g. "Sarit Expo Centre, Nairobi"' ],
	'photo' => [ 'Photo address (optional)', 'url', 'A photo of the stand or the event poster' ],
	'ig'    => [ 'Instagram link (optional)', 'url', 'The post or highlight about this pop-up' ],
];
add_action( 'add_meta_boxes', function () {
	add_meta_box( 'bs_popup_details', 'Date, venue & links', function ( $post ) {
		wp_nonce_field( 'bs_popup', 'bs_popup_nonce' );
		echo '<table class="form-table">';
		foreach ( BS_POPUP_FIELDS as $k => [ $label, $type, $hint ] ) {
			printf( '<tr><th><label for="bs_%1$s">%2$s</label></th><td><input type="%3$s" id="bs_%1$s" name="bs_popup[%1$s]" value="%4$s" class="regular-text">%5$s</td></tr>', esc_attr( $k ), esc_html( $label ), esc_attr( $type ), esc_attr( get_post_meta( $post->ID, "_bs_$k", true ) ), $hint ? '<p class="description">' . esc_html( $hint ) . '</p>' : '' );
		}
		echo '</table><p class="description">A pop-up with a start date in the future shows on the home page and the Pop-ups page with a countdown. Past ones move to the pop-up history. Write a line about it in the box above.</p>';
	}, 'bs_popup', 'normal', 'high' );
} );
add_action( 'save_post_bs_popup', function ( $post_id ) {
	if ( ! isset( $_POST['bs_popup_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['bs_popup_nonce'] ), 'bs_popup' ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	foreach ( (array) wp_unslash( $_POST['bs_popup'] ?? [] ) as $k => $v ) { // phpcs:ignore
		if ( isset( BS_POPUP_FIELDS[ $k ] ) ) update_post_meta( $post_id, "_bs_$k", BS_POPUP_FIELDS[ $k ][1] === 'url' ? esc_url_raw( $v ) : sanitize_text_field( $v ) );
	}
} );
add_filter( 'manage_bs_popup_posts_columns', fn( $c ) => array_slice( $c, 0, 2 ) + [ 'bs_when' => 'When', 'bs_where' => 'Where' ] );
add_action( 'manage_bs_popup_posts_custom_column', function ( $col, $id ) {
	if ( $col === 'bs_when' ) echo esc_html( bs_popup( get_post( $id ) )['when'] );
	if ( $col === 'bs_where' ) echo esc_html( trim( get_post_meta( $id, '_bs_venue', true ) . ', ' . get_post_meta( $id, '_bs_area', true ), ', ' ) );
}, 10, 2 );

function bs_popup( WP_Post $p ) {
	$m     = fn( $k ) => (string) get_post_meta( $p->ID, "_bs_$k", true );
	$start = $m( 'date' );
	$end   = $m( 'end' );
	$fmt   = fn( $d, $f ) => $d ? wp_date( $f, strtotime( $d . ' 12:00' ) ) : '';
	$when  = $m( 'label' ) ?: ( $end && $end !== $start ? ( substr( $start, 0, 7 ) === substr( $end, 0, 7 ) ? $fmt( $start, 'j' ) . '–' . $fmt( $end, 'j F Y' ) : $fmt( $start, 'j M' ) . ' – ' . $fmt( $end, 'j M Y' ) ) : $fmt( $start, 'l j F Y' ) );
	$today = wp_date( 'Y-m-d' );
	return [
		'id'       => $p->ID,
		'title'    => get_the_title( $p ),
		'note'     => wp_strip_all_tags( $p->post_content ),
		'start'    => $start,
		'end'      => $end ?: $start,
		'when'     => $when,
		'time'     => $m( 'time' ),
		'venue'    => $m( 'venue' ),
		'area'     => $m( 'area' ),
		'map'      => $m( 'map' ),
		'photo'    => $m( 'photo' ),
		'ig'       => $m( 'ig' ),
		'upcoming' => $start && ( $end ?: $start ) >= $today,
	];
}
function bs_popups() {
	$all = array_map( 'bs_popup', get_posts( [ 'post_type' => 'bs_popup', 'post_status' => 'publish', 'numberposts' => 50 ] ) );
	usort( $all, fn( $a, $b ) => strcmp( $a['start'], $b['start'] ) );
	$next = array_values( array_filter( $all, fn( $e ) => $e['upcoming'] ) );
	$past = array_reverse( array_values( array_filter( $all, fn( $e ) => ! $e['upcoming'] ) ) );
	return [ $next, $past ];
}
function bs_maps_link( $q ) {
	return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $q );
}
function bs_calendar_link( array $e ) {
	$s = str_replace( '-', '', $e['start'] );
	$f = str_replace( '-', '', wp_date( 'Y-m-d', strtotime( $e['end'] . ' +1 day' ) ) );
	return 'https://calendar.google.com/calendar/render?action=TEMPLATE&text=' . rawurlencode( 'Bloem Sefa at ' . $e['title'] ) . '&dates=' . $s . '/' . $f . '&location=' . rawurlencode( trim( $e['venue'] . ', ' . $e['area'], ', ' ) ) . '&details=' . rawurlencode( 'Pop-up flower shop by Bloem Sefa. ' . BS_INSTAGRAM );
}

// The next pop-up (with a countdown) or "date coming soon", then the history.
function bs_popup_next_html( $next ) {
	if ( ! $next ) {
		$clip = get_stylesheet_directory_uri() . '/assets/clips/popup';
		return '<div class="bs-next bs-next--tba"><video src="' . esc_url( $clip . '.mp4' ) . '" poster="' . esc_url( $clip . '.jpg' ) . '" autoplay muted loop playsinline aria-label="Our stand at the Centenary Plant &amp; Flower Show, Sarit Expo Centre"></video><div><p class="bs-eyebrow">Next pop-up</p><h3>Date &amp; venue coming soon</h3><p>We announce every pop-up on Instagram a week or two ahead. Join the Plant Club and we\'ll send you the date, the venue and what\'s in bloom.</p><div class="bs-next__ctas"><a class="wp-element-button bs-wa-btn" href="' . esc_url( bs_wa_link( 'Hi Bloem Sefa, please let me know when and where your next pop-up is 🌸' ) ) . '" target="_blank" rel="noopener">' . BS_WA_ICON . 'Remind me on WhatsApp</a><a class="wp-element-button bs-btn-ghost" href="' . esc_url( BS_INSTAGRAM ) . '" target="_blank" rel="noopener">Follow @bloemsefa</a></div></div></div>';
	}
	$e    = $next[0];
	$msg  = 'Hi Bloem Sefa, please remind me about your pop-up at ' . $e['title'] . ' (' . $e['when'] . ') 🌸';
	$clip = get_stylesheet_directory_uri() . '/assets/clips/popup';
	return '<div class="bs-next" data-bs-countdown="' . esc_attr( $e['start'] ) . '">'
		// No photo yet: a clip of one of our stands.
		. ( $e['photo'] ? '<img src="' . esc_url( $e['photo'] ) . '" alt="" loading="lazy">' : '<video src="' . esc_url( $clip . '.mp4' ) . '" poster="' . esc_url( $clip . '.jpg' ) . '" autoplay muted loop playsinline aria-hidden="true"></video>' )
		. '<div><p class="bs-eyebrow">Next pop-up</p><h3>' . esc_html( $e['title'] ) . '</h3>'
		. '<p class="bs-next__when">📅 ' . esc_html( $e['when'] ) . ( $e['time'] ? ' · ' . esc_html( $e['time'] ) : '' ) . '<br>📍 ' . esc_html( trim( $e['venue'] . ', ' . $e['area'], ', ' ) ) . '</p>'
		. '<div class="bs-countdown" aria-label="Time until the pop-up"><span><b data-d>–</b>days</span><span><b data-h>–</b>hours</span><span><b data-m>–</b>mins</span></div>'
		. ( $e['note'] ? '<p>' . esc_html( $e['note'] ) . '</p>' : '' )
		. '<div class="bs-next__ctas"><a class="wp-element-button bs-wa-btn" href="' . esc_url( bs_wa_link( $msg ) ) . '" target="_blank" rel="noopener">' . BS_WA_ICON . 'Remind me on WhatsApp</a>'
		. ( $e['map'] ? '<a class="wp-element-button bs-btn-ghost" href="' . esc_url( bs_maps_link( $e['map'] ) ) . '" target="_blank" rel="noopener">Directions</a>' : '' )
		. '<a class="bs-link" href="' . esc_url( bs_calendar_link( $e ) ) . '" target="_blank" rel="noopener">+ Add to calendar</a></div></div></div>';
}
function bs_popup_card( array $e, $i ) {
	return '<li class="bs-pop' . ( $i === 0 ? ' is-on' : '' ) . '"><button type="button" data-bs-map="' . esc_attr( $e['map'] ) . '" data-bs-map-title="' . esc_attr( $e['title'] . ' – ' . $e['venue'] ) . '" aria-pressed="' . ( $i === 0 ? 'true' : 'false' ) . '">'
		. ( $e['photo'] ? '<img src="' . esc_url( $e['photo'] ) . '" alt="" loading="lazy" width="640" height="800">' : '' )
		. '<span class="bs-pop__when">' . esc_html( $e['when'] ) . '</span><strong>' . esc_html( $e['title'] ) . '</strong><em>' . esc_html( trim( $e['venue'] . ', ' . $e['area'], ', ' ) ) . '</em></button>'
		. ( $e['note'] ? '<p>' . esc_html( $e['note'] ) . '</p>' : '' )
		. ( $e['ig'] ? '<a class="bs-link" href="' . esc_url( $e['ig'] ) . '" target="_blank" rel="noopener">See it on Instagram →</a>' : '' ) . '</li>';
}
add_shortcode( 'bs_popups', function ( $atts ) {
	$atts             = shortcode_atts( [ 'teaser' => '' ], $atts );
	[ $next, $past ]  = bs_popups();
	$first            = array_values( array_filter( $past, fn( $e ) => $e['map'] ) )[0] ?? null;
	$h                = '<div class="bs-popups' . ( $atts['teaser'] ? ' bs-popups--teaser' : '' ) . '">' . bs_popup_next_html( $next );
	if ( $past ) {
		$h .= '<div class="bs-popups__history"><div class="bs-popups__head"><h3>Where we\'ve popped up</h3><p>Tap a market to see it on the map.</p></div><ol class="bs-pops">';
		foreach ( $past as $i => $e ) {
			$h .= bs_popup_card( $e, $e === $first ? 0 : $i + 1 );
		}
		$h .= '</ol>';
		if ( $first ) {
			$h .= '<figure class="bs-map"><iframe title="Map: ' . esc_attr( $first['title'] ) . '" data-bs-map-frame src="https://maps.google.com/maps?q=' . rawurlencode( $first['map'] ) . '&amp;z=14&amp;output=embed" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe><figcaption data-bs-map-caption>' . esc_html( $first['title'] . ' – ' . $first['venue'] ) . '</figcaption></figure>';
		}
		$h .= '</div>';
	}
	return $h . '</div>';
} );

// Plant Club and garden centre sign-ups: saved under Plant Club in the admin.
add_shortcode( 'bs_signup', function ( $atts ) {
	$atts   = shortcode_atts( [ 'type' => 'club', 'button' => 'Join the Plant Club' ], $atts );
	$garden = $atts['type'] === 'garden';
	$h      = '<form class="bs-signup' . ( $garden ? ' bs-signup--garden' : '' ) . '" data-bs-signup data-type="' . esc_attr( $atts['type'] ) . '">';
	$h     .= '<label><span>Your name</span><input name="name" required autocomplete="name" placeholder="Your name"></label>';
	$h     .= '<label><span>WhatsApp number</span><input name="phone" type="tel" required autocomplete="tel" placeholder="07XX XXX XXX"></label>';
	if ( $garden ) {
		$h .= '<fieldset><legend>I\'d love to hear about</legend><div class="bs-signup__chips">';
		foreach ( [ 'opening' => 'Opening day', 'workshops' => 'Plant workshops', 'landscaping' => 'Garden & landscaping help', 'events' => 'Plants for events & offices' ] as $k => $l ) {
			$h .= '<label><input type="checkbox" name="interests" value="' . esc_attr( $l ) . '"' . ( $k === 'opening' ? ' checked' : '' ) . '><span>' . esc_html( $l ) . '</span></label>';
		}
		$h .= '</div></fieldset>';
	}
	$h .= '<input type="text" name="website" tabindex="-1" autocomplete="off" class="bs-hp" aria-hidden="true">';
	$h .= '<button type="submit" class="wp-element-button">' . esc_html( $atts['button'] ) . '</button><p class="bs-signup__ok" data-bs-signup-ok hidden></p></form>';
	return $h;
} );
add_action( 'rest_api_init', function () {
	register_rest_route( 'bs/v1', '/signup', [
		'methods'             => 'POST',
		'permission_callback' => '__return_true',
		'callback'            => function ( WP_REST_Request $r ) {
			if ( $r['website'] ) return [ 'ok' => true ]; // Bots fill the hidden field.
			$name  = sanitize_text_field( (string) $r['name'] );
			$phone = sanitize_text_field( (string) $r['phone'] );
			if ( $name === '' || ! preg_match( '/\d{9,}/', preg_replace( '/\D/', '', $phone ) ) ) {
				return new WP_Error( 'bs_signup', 'Please add your name and a phone number.', [ 'status' => 400 ] );
			}
			$type = $r['type'] === 'garden' ? 'Garden Centre' : 'Plant Club';
			$id   = wp_insert_post( [ 'post_type' => 'bs_signup', 'post_status' => 'private', 'post_title' => "$name · $phone · $type", 'post_content' => sanitize_text_field( implode( ', ', (array) $r['interests'] ) ) ] );
			return [ 'ok' => (bool) $id ];
		},
	] );
} );

/* -------------------------------------------------------------------------
 * Quick view, cart, checkout, order confirmation
 * ---------------------------------------------------------------------- */

function bs_freebar_html() {
	$total = WC()->cart ? (float) WC()->cart->get_displayed_subtotal() : 0;
	$left  = max( 0, BS_FREE_DELIVERY - $total );
	$pct   = min( 100, round( $total / BS_FREE_DELIVERY * 100 ) );
	$msg   = $left > 0
		? 'Add <strong>' . bs_money( $left ) . '</strong> more for <strong>free Nairobi delivery</strong>'
		: '<strong>You\'ve unlocked free Nairobi delivery! 🌿</strong>';
	return '<div class="bs-freebar" data-bs-freebar>' . $msg . '<div class="bs-freebar__track"><div class="bs-freebar__fill" style="width:' . $pct . '%"></div></div></div>';
}
function bs_wa_cart_html() {
	return '<button type="button" class="bs-wa-cart" data-bs-wa-cart>' . BS_WA_ICON . 'Send this order on WhatsApp</button>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => bs_freebar_html() . $c );
add_filter( 'render_block_woocommerce/proceed-to-checkout-block', fn( $c ) => $c . bs_wa_cart_html() );
add_filter( 'render_block_woocommerce/mini-cart-contents', function ( $c ) {
	return preg_replace( '#(<div[^>]*wp-block-woocommerce-filled-mini-cart-contents-block[^>]*>)#', '$1' . bs_freebar_html(), $c, 1 );
} );
add_filter( 'render_block_woocommerce/mini-cart-footer-block', fn( $c ) => $c . '<div class="bs-wa-cart-wrap">' . bs_wa_cart_html() . '</div>' );

// Riders need a landmark; gifts and made-to-order pieces need a day.
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
		return;
	}
	woocommerce_register_additional_checkout_field( [
		'id'       => 'bs/landmark',
		'label'    => 'Gate, building or nearest landmark',
		'location' => 'address',
		'type'     => 'text',
		'required' => false,
	] );
	woocommerce_register_additional_checkout_field( [
		'id'       => 'bs/day',
		'label'    => 'Preferred delivery or pickup day (optional)',
		'location' => 'order',
		'type'     => 'text',
		'required' => false,
	] );
} );

// Order code, what happens next and a WhatsApp summary on the order confirmation page.
function bs_order_code( WC_Order $order ) {
	return 'BS-' . $order->get_order_number() . '-' . strtoupper( substr( $order->get_order_key(), -4 ) );
}
function bs_eta( WC_Order $order ) {
	$method = strtolower( $order->get_shipping_method() );
	if ( str_contains( $method, 'pop-up' ) || str_contains( $method, 'collect' ) ) {
		return 'Collect at our next pop-up market: we\'ll WhatsApp you the date and venue, and keep your plants aside until then.';
	}
	return 'Delivery by rider: we\'ll call you to agree a day and time, then bring your plants upright and freshly watered.';
}
function bs_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi Bloem Sefa, I just placed order ' . bs_order_code( $order ) . ':' ];
	foreach ( $order->get_items() as $item ) {
		$opts = [];
		foreach ( $item->get_formatted_meta_data() as $meta ) { // Skips WooCommerce's own "_" fields.
			$opts[] = wp_strip_all_tags( $meta->display_key . ': ' . $meta->display_value );
		}
		$lines[] = '• ' . $item->get_quantity() . ' × ' . $item->get_name() . ( $opts ? ' (' . implode( '; ', $opts ) . ')' : '' ) . ' – ' . bs_money( $item->get_total() );
	}
	$lines[] = 'Total: ' . bs_money( $order->get_total() );
	$lines[] = 'Delivery: ' . $order->get_shipping_method();
	$address = trim( implode( ', ', array_filter( [ $order->get_shipping_address_1(), $order->get_shipping_city() ] ) ) );
	if ( $address ) {
		$lines[] = 'Deliver to: ' . $address;
	}
	$lines[] = 'Payment: ' . $order->get_payment_method_title();
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	return bs_wa_link( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) {
		return $content;
	}
	return $content . '<div class="bs-thanks"><p class="bs-thanks__code">Your order number <strong>' . esc_html( bs_order_code( $order ) ) . '</strong></p><p class="bs-thanks__eta">' . esc_html( bs_eta( $order ) ) . '</p><p>We\'ll be in touch shortly to confirm. To speed things up, send us the order on WhatsApp.</p><a class="wp-element-button bs-wa-btn" href="' . esc_attr( bs_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">' . BS_WA_ICON . 'Send order summary on WhatsApp</a><p class="bs-thanks__channel">📸 Follow <a href="' . esc_url( BS_INSTAGRAM ) . '" target="_blank" rel="noopener">@bloemsefa on Instagram</a> for pop-up dates, what\'s in bloom and care tips.</p></div>';
} );
add_action( 'woocommerce_admin_order_data_after_order_details', function ( $order ) {
	echo '<p class="form-field form-field-wide"><strong>Order number:</strong> ' . esc_html( bs_order_code( $order ) ) . '</p>';
} );

// Staff edit the card badge, care sheet and options on the product screen.
add_action( 'woocommerce_product_options_general_product_data', function () {
	echo '<div class="options_group">';
	woocommerce_wp_text_input( [ 'id' => '_bs_badge', 'label' => 'Card badge', 'description' => 'Shown on the product photo, e.g. "6 colours" or "Christmas season".', 'desc_tip' => true ] );
	woocommerce_wp_checkbox( [ 'id' => '_bs_pots', 'label' => 'Pot choices', 'description' => 'Offer the pot upgrades, soil mix and saucer on this plant.', 'cbvalue' => 'yes' ] );
	woocommerce_wp_checkbox( [ 'id' => '_bs_made', 'label' => 'Made to order', 'description' => 'Hand-made arrangements: asks for the date at checkout.', 'cbvalue' => 'yes' ] );
	foreach ( BS_CARE_ROWS as $key => $label ) {
		woocommerce_wp_textarea_input( [ 'id' => "_bs_care_$key", 'label' => 'Care: ' . $label, 'rows' => 2 ] );
	}
	echo '</div>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	if ( isset( $_POST['_bs_badge'] ) ) $product->update_meta_data( '_bs_badge', sanitize_text_field( wp_unslash( $_POST['_bs_badge'] ) ) ); // phpcs:ignore
	foreach ( [ '_bs_pots', '_bs_made' ] as $key ) {
		$product->update_meta_data( $key, isset( $_POST[ $key ] ) ? 'yes' : 'no' ); // phpcs:ignore
	}
	foreach ( array_keys( BS_CARE_ROWS ) as $key ) {
		if ( isset( $_POST[ "_bs_care_$key" ] ) ) $product->update_meta_data( "_bs_care_$key", sanitize_textarea_field( wp_unslash( $_POST[ "_bs_care_$key" ] ) ) ); // phpcs:ignore
	}
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

// Kenyan addresses: no postcode, and riders need a phone number.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode'] = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['city']     = [ 'label' => 'Estate / Area (e.g. Karen, Kilimani, Runda)' ];
	$locale['KE']['phone']    = [ 'required' => true ];
	return $locale;
} );

// Demo stores ship web-sized photos and skip thumbnails (see setup.php).
if ( get_option( 'bs_fast_images' ) === 'yes' ) {
	add_filter( 'woocommerce_resize_images', '__return_false' );
	add_filter( 'woocommerce_background_image_regeneration', '__return_false' );
}

// The whole catalogue fits on one shop page (the static copy filters in the browser).
add_filter( 'loop_shop_per_page', fn() => 24 );

// Shop thumbnails match the 4:5 product cards (WooCommerce's default is a 300px square).
add_filter( 'woocommerce_get_image_size_thumbnail', function () {
	return [ 'width' => 480, 'height' => 600, 'crop' => 1 ];
} );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$uri = get_stylesheet_directory_uri();
	echo '<link rel="icon" href="' . esc_url( $uri . '/assets/icon.svg' ) . '" type="image/svg+xml">' . "\n" . '<link rel="apple-touch-icon" href="' . esc_url( $uri . '/assets/icon.png' ) . '">' . "\n" . '<meta name="theme-color" content="#1E3A1A">' . "\n";
} );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src|poster)="/(?!/)#', '$1="' . $home, $content );
} );

// The shop shows no WordPress toolbar, version tags or discovery links. Staff work from /wp-admin.
add_filter( 'show_admin_bar', '__return_false' );
add_filter( 'the_generator', '__return_empty_string' );
add_filter( 'xmlrpc_enabled', '__return_false' );
add_filter( 'emoji_svg_url', '__return_false' );
add_filter( 'wp_headers', function ( $headers ) {
	unset( $headers['X-Pingback'] );
	return $headers;
} );
add_action( 'init', function () {
	remove_action( 'wp_head', 'wp_generator' );
	remove_action( 'wp_head', 'rsd_link' );
	remove_action( 'wp_head', 'wlwmanifest_link' );
	remove_action( 'wp_head', 'wp_shortlink_wp_head' );
	remove_action( 'wp_head', 'rest_output_link_wp_head' );
	remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
	remove_action( 'wp_head', 'feed_links', 2 );
	remove_action( 'wp_head', 'feed_links_extra', 3 );
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_footer_scripts', 'print_emoji_detection_script' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_emoji_styles' );
	remove_action( 'template_redirect', 'rest_output_link_header', 11 );
	remove_action( 'template_redirect', 'wp_shortlink_header', 11 );
} );

// The staff login page carries the shop's logo instead of the WordPress one.
add_action( 'login_enqueue_scripts', function () {
	$logo = esc_url( get_stylesheet_directory_uri() . '/assets/icon.svg' );
	echo "<style>body.login{background:#F9F8F3}body.login #login h1 a{background:url($logo) center/contain no-repeat;width:96px;height:96px}body.login .button-primary{background:#2D5A27;border-color:#2D5A27}#backtoblog,.language-switcher{display:none}</style>";
} );
add_filter( 'login_title', fn( $title ) => str_replace( [ ' &#8212; WordPress', ' — WordPress' ], '', $title ) );
add_filter( 'login_headerurl', fn() => home_url( '/' ) );
add_filter( 'login_headertext', fn() => 'Bloem Sefa' );
